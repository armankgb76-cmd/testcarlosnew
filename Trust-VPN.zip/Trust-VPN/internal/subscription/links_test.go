package subscription

import (
	"encoding/base64"
	"encoding/json"
	"net/url"
	"strings"
	"testing"

	"github.com/your-org/trust-vpn/internal/proxysettings"
)

func TestVLESSLinkTLS(t *testing.T) {
	in := EffectiveInbound{Network: "tcp", HeaderType: "", Port: 443, Security: "tls", SNI: "example.com", Fingerprint: "chrome", ALPN: "h2"}
	settings := proxysettings.Settings{Type: proxysettings.VLESS, VLESS: &proxysettings.VLESSSettings{ID: "uuid-1", Flow: proxysettings.FlowVision}}

	link, err := BuildLink("My Server", "1.2.3.4", in, settings, "")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if !strings.HasPrefix(link, "vless://uuid-1@1.2.3.4:443?") {
		t.Fatalf("unexpected link prefix: %s", link)
	}
	if !strings.HasSuffix(link, "#My%20Server") {
		t.Errorf("remark not percent-encoded as expected (want %%20 for space): %s", link)
	}

	q := parseLinkQuery(t, link)
	want := map[string]string{
		"security": "tls", "type": "tcp", "headerType": "", "flow": "xtls-rprx-vision",
		"sni": "example.com", "fp": "chrome", "alpn": "h2", "path": "", "host": "",
	}
	for k, v := range want {
		if got := q.Get(k); got != v {
			t.Errorf("query param %q = %q, want %q", k, got, v)
		}
	}
}

func TestVLESSLinkFlowOmittedOnNonTCP(t *testing.T) {
	// Matches vless()'s guard: flow only appears for tls/reality + tcp/raw/kcp
	// + non-http headerType - a ws transport must never carry flow.
	in := EffectiveInbound{Network: "ws", Port: 443, Security: "tls", SNI: "example.com", Path: "/ws", HostHeader: "example.com"}
	settings := proxysettings.Settings{Type: proxysettings.VLESS, VLESS: &proxysettings.VLESSSettings{ID: "uuid-1", Flow: proxysettings.FlowVision}}

	link, _ := BuildLink("r", "1.2.3.4", in, settings, "")
	q := parseLinkQuery(t, link)
	if q.Has("flow") {
		t.Errorf("flow present on a ws transport, want omitted: %s", link)
	}
	if q.Get("path") != "/ws" || q.Get("host") != "example.com" {
		t.Errorf("ws path/host not set correctly: %s", link)
	}
}

func TestVLESSLinkReality(t *testing.T) {
	in := EffectiveInbound{Network: "tcp", Port: 443, Security: "reality", SNI: "www.microsoft.com", Fingerprint: "chrome", RealityPublicKey: "pubkey123", RealityShortID: "ab12"}
	settings := proxysettings.Settings{Type: proxysettings.VLESS, VLESS: &proxysettings.VLESSSettings{ID: "uuid-1"}}

	link, _ := BuildLink("r", "1.2.3.4", in, settings, "")
	q := parseLinkQuery(t, link)
	if q.Get("pbk") != "pubkey123" || q.Get("sid") != "ab12" || q.Get("sni") != "www.microsoft.com" {
		t.Errorf("reality params missing/wrong: %s", link)
	}
	if q.Has("alpn") {
		t.Errorf("alpn should not appear for reality security: %s", link)
	}
}

func TestTrojanLinkPasswordEscaped(t *testing.T) {
	in := EffectiveInbound{Network: "tcp", Port: 443, Security: "tls", SNI: "example.com"}
	settings := proxysettings.Settings{Type: proxysettings.Trojan, Trojan: &proxysettings.TrojanSettings{Password: "p@ss word"}}

	link, _ := BuildLink("r", "1.2.3.4", in, settings, "")
	if !strings.HasPrefix(link, "trojan://p%40ss%20word@1.2.3.4:443?") {
		t.Errorf("password not percent-encoded correctly: %s", link)
	}
}

func TestVMessLinkJSON(t *testing.T) {
	in := EffectiveInbound{Network: "ws", HeaderType: "none", Port: 8080, Security: "none", Path: "/vm", HostHeader: "cdn.example.com"}
	settings := proxysettings.Settings{Type: proxysettings.VMess, VMess: &proxysettings.VMessSettings{ID: "vmess-uuid"}}

	link, err := BuildLink("VMess Server", "5.6.7.8", in, settings, "")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if !strings.HasPrefix(link, "vmess://") {
		t.Fatalf("missing vmess:// prefix: %s", link)
	}
	raw, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(link, "vmess://"))
	if err != nil {
		t.Fatalf("vmess payload is not valid base64: %v", err)
	}
	var payload map[string]interface{}
	if err := json.Unmarshal(raw, &payload); err != nil {
		t.Fatalf("vmess payload is not valid JSON: %v", err)
	}
	wantFields := map[string]interface{}{
		"add": "5.6.7.8", "port": "8080", "id": "vmess-uuid", "net": "ws",
		"path": "/vm", "host": "cdn.example.com", "ps": "VMess Server", "v": "2", "tls": "none",
	}
	for k, v := range wantFields {
		if payload[k] != v {
			t.Errorf("vmess JSON field %q = %v, want %v", k, payload[k], v)
		}
	}
}

func TestShadowsocksLink(t *testing.T) {
	in := EffectiveInbound{Port: 8388}
	settings := proxysettings.Settings{Type: proxysettings.Shadowsocks, Shadowsocks: &proxysettings.ShadowsocksSettings{Password: "secret", Method: proxysettings.Chacha20Poly1305}}

	link, err := BuildLink("SS Node", "9.9.9.9", in, settings, "")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if !strings.HasPrefix(link, "ss://") || !strings.HasSuffix(link, "#SS%20Node") {
		t.Fatalf("unexpected ss link shape: %s", link)
	}
	userinfo := strings.TrimSuffix(strings.TrimPrefix(link, "ss://"), "@9.9.9.9:8388#SS%20Node")
	decoded, err := base64.StdEncoding.DecodeString(userinfo)
	if err != nil {
		t.Fatalf("ss userinfo is not valid base64: %v", err)
	}
	if string(decoded) != "chacha20-ietf-poly1305:secret" {
		t.Errorf("ss userinfo = %q, want method:password", decoded)
	}
}

func TestHysteria2Link(t *testing.T) {
	in := EffectiveInbound{Port: 443, SNI: "example.com", AllowInsecure: true, Hysteria2ObfsPassword: "obfs-pw"}
	settings := proxysettings.Settings{Type: proxysettings.Hysteria2, Hysteria2: &proxysettings.Hysteria2Settings{Password: "user-pw"}}

	link, err := BuildLink("HY2 Node", "5.6.7.8", in, settings, "")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if !strings.HasPrefix(link, "hysteria2://user-pw@5.6.7.8:443/?") {
		t.Fatalf("unexpected hysteria2 link prefix: %s", link)
	}
	if !strings.HasSuffix(link, "#HY2%20Node") {
		t.Errorf("remark not percent-encoded as expected: %s", link)
	}
	q := parseLinkQuery(t, link)
	want := map[string]string{"sni": "example.com", "insecure": "1", "obfs": "salamander", "obfs-password": "obfs-pw"}
	for k, v := range want {
		if got := q.Get(k); got != v {
			t.Errorf("query param %q = %q, want %q", k, got, v)
		}
	}
}

func TestHysteria2LinkOmitsObfsWhenUnset(t *testing.T) {
	in := EffectiveInbound{Port: 443, SNI: "example.com"}
	settings := proxysettings.Settings{Type: proxysettings.Hysteria2, Hysteria2: &proxysettings.Hysteria2Settings{Password: "user-pw"}}

	link, err := BuildLink("HY2 Node", "5.6.7.8", in, settings, "")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	q := parseLinkQuery(t, link)
	if q.Has("obfs") || q.Has("obfs-password") {
		t.Errorf("obfs params present with no obfs password configured: %s", link)
	}
	if q.Has("insecure") {
		t.Errorf("insecure=1 present although AllowInsecure was false: %s", link)
	}
}

func TestTUICLink(t *testing.T) {
	in := EffectiveInbound{Port: 443, SNI: "example.com", CongestionControl: "bbr"}
	settings := proxysettings.Settings{Type: proxysettings.TUIC, TUIC: &proxysettings.TUICSettings{ID: "uuid-1", Password: "p@ss:w0rd"}}

	link, err := BuildLink("TUIC Node", "5.6.7.8", in, settings, "")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if !strings.HasPrefix(link, "tuic://uuid-1:") {
		t.Fatalf("unexpected tuic link prefix: %s", link)
	}
	if !strings.HasSuffix(link, "#TUIC%20Node") {
		t.Errorf("remark not percent-encoded as expected: %s", link)
	}
	q := parseLinkQuery(t, link)
	want := map[string]string{"sni": "example.com", "alpn": "h3", "congestion_control": "bbr", "udp_relay_mode": "native"}
	for k, v := range want {
		if got := q.Get(k); got != v {
			t.Errorf("query param %q = %q, want %q", k, got, v)
		}
	}
}

func TestTUICLinkDefaultsCongestionControlToCubic(t *testing.T) {
	in := EffectiveInbound{Port: 443, SNI: "example.com"}
	settings := proxysettings.Settings{Type: proxysettings.TUIC, TUIC: &proxysettings.TUICSettings{ID: "uuid-1", Password: "pw"}}

	link, err := BuildLink("TUIC Node", "5.6.7.8", in, settings, "")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if got := parseLinkQuery(t, link).Get("congestion_control"); got != "cubic" {
		t.Errorf("congestion_control = %q, want the node's own default %q", got, "cubic")
	}
}

func TestNaiveLinkOverTLS(t *testing.T) {
	in := EffectiveInbound{Port: 443, Security: "tls", AllowInsecure: true}
	settings := proxysettings.Settings{Type: proxysettings.Naive, Naive: &proxysettings.NaiveSettings{Password: "user-pw"}}

	link, err := BuildLink("Naive Node", "5.6.7.8", in, settings, "zz_claude_naive")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if !strings.HasPrefix(link, "naive+https://zz_claude_naive:user-pw@5.6.7.8:443?") {
		t.Fatalf("unexpected naive link: %s", link)
	}
	q := parseLinkQuery(t, link)
	if q.Get("padding") != "true" || q.Get("insecure") != "1" {
		t.Errorf("missing padding/insecure query params: %s", link)
	}
}

func TestNaiveLinkOverPlainHTTPHasNoSchemedSuffixOrQuery(t *testing.T) {
	in := EffectiveInbound{Port: 8080, Security: "none"}
	settings := proxysettings.Settings{Type: proxysettings.Naive, Naive: &proxysettings.NaiveSettings{Password: "user-pw"}}

	link, err := BuildLink("Naive Node", "5.6.7.8", in, settings, "zz_claude_naive")
	if err != nil {
		t.Fatalf("BuildLink: %v", err)
	}
	if link != "naive://zz_claude_naive:user-pw@5.6.7.8:8080#Naive%20Node" {
		t.Errorf("unexpected plain-HTTP naive link: %s", link)
	}
}

func parseLinkQuery(t *testing.T, link string) url.Values {
	t.Helper()
	idx := strings.Index(link, "?")
	if idx < 0 {
		t.Fatalf("link has no query string: %s", link)
	}
	rest := link[idx+1:]
	if h := strings.Index(rest, "#"); h >= 0 {
		rest = rest[:h]
	}
	q, err := url.ParseQuery(rest)
	if err != nil {
		t.Fatalf("could not parse query from link %s: %v", link, err)
	}
	return q
}
