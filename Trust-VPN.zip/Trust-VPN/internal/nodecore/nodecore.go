package nodecore

import (
	"context"
	"fmt"

	box "github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/option"
	"github.com/sagernet/sing/common/auth"

	forkedanytls "github.com/your-org/trust-vpn/internal/nodecore/anytls"
	forkedhysteria "github.com/your-org/trust-vpn/internal/nodecore/hysteria"
	forkedhysteria2 "github.com/your-org/trust-vpn/internal/nodecore/hysteria2"
	forkednaive "github.com/your-org/trust-vpn/internal/nodecore/naive"
	forkedshadowtls "github.com/your-org/trust-vpn/internal/nodecore/shadowtls"
	forkedshadowsocks "github.com/your-org/trust-vpn/internal/nodecore/shadowsocks"
	forkedsnell "github.com/your-org/trust-vpn/internal/nodecore/snell"
	"github.com/your-org/trust-vpn/internal/nodecore/traffic"
	forkedtrojan "github.com/your-org/trust-vpn/internal/nodecore/trojan"
	forkedtuic "github.com/your-org/trust-vpn/internal/nodecore/tuic"
	forkedvless "github.com/your-org/trust-vpn/internal/nodecore/vless"
	forkedvmess "github.com/your-org/trust-vpn/internal/nodecore/vmess"
)

// Node wraps a running sing-box instance built from the restricted
// registries in registry.go.
type Node struct {
	box     *box.Box
	Traffic *traffic.Manager
	// conns is every client connection this instance has accepted and not yet
	// finished with; Close ends them all. See traffic.ConnGroup.
	conns *traffic.ConnGroup
}

// New builds a sing-box instance from the given options - it does not
// initialize or start anything yet, call Start for that. (Box.Start does
// its own internal pre-start pass; calling Box.PreStart here too would run
// it twice and panic on a double-started component.)
//
// mgr is threaded through sing-box's own inbound-construction context (see
// traffic.NewContext) so the forked inbounds can wrap every accepted
// connection with a byte counter - the panel has no way to poll Xray-style
// stats out of sing-box, so counting happens here, at construction time,
// rather than via any later registration step.
func New(ctx context.Context, opts option.Options, mgr *traffic.Manager) (*Node, error) {
	conns := traffic.NewConnGroup()
	ctx = traffic.WithConnGroup(traffic.NewContext(ctx, mgr), conns)
	ctx = box.Context(ctx, InboundRegistry(), OutboundRegistry(), EndpointRegistry(), DNSTransportRegistry(), ServiceRegistry(), CertificateProviderRegistry())
	instance, err := box.New(box.Options{
		Context: ctx,
		Options: opts,
	})
	if err != nil {
		return nil, fmt.Errorf("nodecore: build instance: %w", err)
	}
	return &Node{box: instance, Traffic: mgr, conns: conns}, nil
}

// Start initializes every component and opens every configured inbound's
// listener.
func (n *Node) Start() error {
	return n.box.Start()
}

// Close tears down every inbound, outbound and background service, then closes
// every client connection the instance had accepted. Closing the box stops the
// listeners and the router, which ends the connections the router is relaying;
// what is left - chiefly a multiplexed session, whose carrier connection the
// inbound reads itself - would keep answering its client with errors from a dead
// router until the client gave up on its own.
func (n *Node) Close() error {
	err := n.box.Close()
	n.conns.CloseAll()
	return err
}

// User is one proxy account in the protocol-neutral shape UpdateUsers takes.
type User struct {
	Name     string
	UUID     string // vless, vmess, tuic
	Password string // trojan, shadowsocks, hysteria2, tuic
	Flow     string // vless
	// UserKey is snell's own per-user secret - a distinct field from Password
	// because, unlike every password-style field above, a snell inbound
	// ALSO has an inbound-level PSK the user's own key sits behind (see
	// internal/nodecore/snell's own doc comment); reusing Password would
	// blur the two.
	UserKey string // snell
}

// UpdateUsers replaces the user list on an already-running inbound identified
// by tag, with no listener restart and no impact on connections already
// established. protocol is one of vless, vmess, trojan, shadowsocks,
// hysteria2 or tuic and must match the inbound's actual type. On error the
// running list is unchanged.
func (n *Node) UpdateUsers(tag, protocol string, users []User) error {
	switch protocol {
	case "vless":
		return n.UpdateVLESSUsers(tag, mapUsers(users, func(u User) option.VLESSUser {
			return option.VLESSUser{Name: u.Name, UUID: u.UUID, Flow: u.Flow}
		}))
	case "vmess":
		return n.UpdateVMessUsers(tag, mapUsers(users, func(u User) option.VMessUser {
			return option.VMessUser{Name: u.Name, UUID: u.UUID}
		}))
	case "trojan":
		return n.UpdateTrojanUsers(tag, mapUsers(users, func(u User) option.TrojanUser {
			return option.TrojanUser{Name: u.Name, Password: u.Password}
		}))
	case "shadowsocks":
		return n.UpdateShadowsocksUsers(tag, mapUsers(users, func(u User) option.ShadowsocksUser {
			return option.ShadowsocksUser{Name: u.Name, Password: u.Password}
		}))
	case "hysteria2":
		return n.UpdateHysteria2Users(tag, mapUsers(users, func(u User) option.Hysteria2User {
			return option.Hysteria2User{Name: u.Name, Password: u.Password}
		}))
	case "tuic":
		return n.UpdateTUICUsers(tag, mapUsers(users, func(u User) option.TUICUser {
			return option.TUICUser{Name: u.Name, UUID: u.UUID, Password: u.Password}
		}))
	case "snell":
		return n.UpdateSnellUsers(tag, mapUsers(users, func(u User) option.SnellUser {
			return option.SnellUser{Name: u.Name, UserKey: u.UserKey}
		}))
	case "anytls":
		return n.UpdateAnyTLSUsers(tag, mapUsers(users, func(u User) option.AnyTLSUser {
			return option.AnyTLSUser{Name: u.Name, Password: u.Password}
		}))
	case "hysteria":
		return n.UpdateHysteriaUsers(tag, mapUsers(users, func(u User) option.HysteriaUser {
			return option.HysteriaUser{Name: u.Name, AuthString: u.Password}
		}))
	case "naive":
		return n.UpdateNaiveUsers(tag, mapUsers(users, func(u User) auth.User {
			return auth.User{Username: u.Name, Password: u.Password}
		}))
	case "shadowtls":
		return n.UpdateShadowTLSUsers(tag, mapUsers(users, func(u User) option.ShadowTLSUser {
			return option.ShadowTLSUser{Name: u.Name, Password: u.Password}
		}))
	default:
		return fmt.Errorf("nodecore: unsupported protocol %q", protocol)
	}
}

func mapUsers[T any](users []User, convert func(User) T) []T {
	out := make([]T, len(users))
	for i, u := range users {
		out[i] = convert(u)
	}
	return out
}

// runningInbound looks up the inbound tagged tag and asserts it is the forked
// type T for protocol.
func runningInbound[T any](n *Node, tag, protocol string) (T, error) {
	var zero T
	raw, loaded := n.box.Inbound().Get(tag)
	if !loaded {
		return zero, fmt.Errorf("nodecore: no running inbound tagged %q", tag)
	}
	in, ok := raw.(T)
	if !ok {
		return zero, fmt.Errorf("nodecore: inbound %q is not a %s inbound", tag, protocol)
	}
	return in, nil
}

// UpdateVLESSUsers is UpdateUsers for a VLESS inbound - the entire reason
// internal/nodecore/vless exists. Returns an error if no VLESS inbound with
// that tag is currently running.
func (n *Node) UpdateVLESSUsers(tag string, users []option.VLESSUser) error {
	in, err := runningInbound[*forkedvless.Inbound](n, tag, "VLESS")
	if err != nil {
		return err
	}
	in.UpdateUsers(users)
	return nil
}

// UpdateVMessUsers is UpdateUsers for a VMess inbound.
func (n *Node) UpdateVMessUsers(tag string, users []option.VMessUser) error {
	in, err := runningInbound[*forkedvmess.Inbound](n, tag, "VMess")
	if err != nil {
		return err
	}
	return in.UpdateUsers(users)
}

// UpdateTrojanUsers is UpdateUsers for a Trojan inbound. It fails, changing
// nothing, if two users share a password.
func (n *Node) UpdateTrojanUsers(tag string, users []option.TrojanUser) error {
	in, err := runningInbound[*forkedtrojan.Inbound](n, tag, "Trojan")
	if err != nil {
		return err
	}
	return in.UpdateUsers(users)
}

// UpdateShadowsocksUsers is UpdateUsers for a Shadowsocks inbound. The cipher
// is fixed when the inbound is built; only the users change.
func (n *Node) UpdateShadowsocksUsers(tag string, users []option.ShadowsocksUser) error {
	in, err := runningInbound[*forkedshadowsocks.Inbound](n, tag, "Shadowsocks")
	if err != nil {
		return err
	}
	return in.UpdateUsers(users)
}

// UpdateHysteria2Users is UpdateUsers for a Hysteria2 inbound.
func (n *Node) UpdateHysteria2Users(tag string, users []option.Hysteria2User) error {
	in, err := runningInbound[*forkedhysteria2.Inbound](n, tag, "Hysteria2")
	if err != nil {
		return err
	}
	in.UpdateUsers(users)
	return nil
}

// UpdateHysteriaUsers is UpdateUsers for a Hysteria v1 inbound (not to be
// confused with UpdateHysteria2Users above, a separate protocol).
func (n *Node) UpdateHysteriaUsers(tag string, users []option.HysteriaUser) error {
	in, err := runningInbound[*forkedhysteria.Inbound](n, tag, "Hysteria")
	if err != nil {
		return err
	}
	in.UpdateUsers(users)
	return nil
}

// UpdateNaiveUsers is UpdateUsers for a Naive inbound - unlike every other
// Update*Users method here, this one never fails on a missing/mismatched
// inbound type the way a Service[U]-backed fork's hot path might, since
// internal/nodecore/naive's UpdateUsers takes a plain []auth.User and
// atomically swaps the whole authenticator (see that package's own doc
// comment on why there is no library mutator to call into here).
func (n *Node) UpdateNaiveUsers(tag string, users []auth.User) error {
	in, err := runningInbound[*forkednaive.Inbound](n, tag, "Naive")
	if err != nil {
		return err
	}
	in.UpdateUsers(users)
	return nil
}

// UpdateShadowTLSUsers is UpdateUsers for a ShadowTLS inbound - see
// internal/nodecore/shadowtls's own doc comment on why the actual hot-swap
// happens one layer down, in the vendored+patched third_party/
// sing-shadowtls, not via a generic Service[U] the way the QUIC family's
// forks get for free.
func (n *Node) UpdateShadowTLSUsers(tag string, users []option.ShadowTLSUser) error {
	in, err := runningInbound[*forkedshadowtls.Inbound](n, tag, "ShadowTLS")
	if err != nil {
		return err
	}
	in.UpdateUsers(users)
	return nil
}

// UpdateTUICUsers is UpdateUsers for a TUIC inbound. It fails, changing
// nothing, if a user's UUID is missing or malformed.
func (n *Node) UpdateTUICUsers(tag string, users []option.TUICUser) error {
	in, err := runningInbound[*forkedtuic.Inbound](n, tag, "TUIC")
	if err != nil {
		return err
	}
	return in.UpdateUsers(users)
}

// UpdateSnellUsers is UpdateUsers for a Snell inbound. It fails, changing
// nothing, if a user's UserKey is missing or two users share one.
func (n *Node) UpdateSnellUsers(tag string, users []option.SnellUser) error {
	in, err := runningInbound[*forkedsnell.Inbound](n, tag, "Snell")
	if err != nil {
		return err
	}
	return in.UpdateUsers(users)
}

// UpdateAnyTLSUsers is UpdateUsers for an AnyTLS inbound.
func (n *Node) UpdateAnyTLSUsers(tag string, users []option.AnyTLSUser) error {
	in, err := runningInbound[*forkedanytls.Inbound](n, tag, "AnyTLS")
	if err != nil {
		return err
	}
	in.UpdateUsers(users)
	return nil
}
