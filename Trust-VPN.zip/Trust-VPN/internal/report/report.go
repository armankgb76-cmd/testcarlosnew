// Package report is the central dispatcher for admin/user lifecycle
// notifications, mirroring app/utils/report.py: which events fire, which
// NOTIFY_* flag gates each one, and who the recipients are. The wire
// format and low-level fan-out mechanics live in internal/telegram and
// internal/discord - this package owns policy, not transport.
package report

import (
	"context"
	"log/slog"
	"time"

	"github.com/your-org/trust-vpn/internal/discord"
	"github.com/your-org/trust-vpn/internal/integrationsettings"
	"github.com/your-org/trust-vpn/internal/telegram"
)

// NotifyFlags mirrors the 7 static NOTIFY_* env booleans - config.py never
// makes these DB-overridable, so they're plain config, not part of
// integrationsettings.Values.
type NotifyFlags struct {
	StatusChange      bool
	UserCreated       bool
	UserUpdated       bool
	UserDeleted       bool
	UserDataUsedReset bool // gates both UserDataUsageReset and UserDataResetByNext, matching Python's single NOTIFY_USER_DATA_USED_RESET
	UserSubRevoked    bool
	Login             bool
	InfraAlert        bool
}

// Category* are the keys integrationsettings.Values.TelegramTopicIDs is
// keyed by - one per notification method below, so an admin who has split
// the logger group into per-category topics gets each event type routed to
// its own thread instead of every type sharing one feed (the DM/single-
// channel firehose a reseller bot's before-every-call login was flooding).
const (
	CategoryStatusChange      = "status_change"
	CategoryUserCreated       = "user_created"
	CategoryUserUpdated       = "user_updated"
	CategoryUserDeleted       = "user_deleted"
	CategoryUserDataUsedReset = "user_data_used_reset"
	CategoryUserSubRevoked    = "user_sub_revoked"
	CategoryLogin             = "login"
	CategoryInfraAlert        = "infra_alert"
)

// SettingsFunc resolves the current dynamic settings, called fresh on every
// dispatch - never cached inside this package, since internal/httpapi's
// Store.CachedGetIntegrationSettings already caches the underlying Postgres
// read. This is what makes a sudo admin's PUT /api/settings/integrations
// take effect immediately, matching every integration in Python except its
// Telegram bot object (a restart-only limitation that doesn't exist here:
// sending holds no persistent connection, and the interactive console in
// internal/telegrambot re-resolves the same settings every ~30s).
type SettingsFunc func(ctx context.Context) (integrationsettings.Values, error)

// AdminRef and UserSummary are deliberately narrow - no db/generated
// dependency - matching internal/subscription/vars.go's UserInfo
// convention, so this package stays a pure policy layer.
type AdminRef struct {
	Username       string
	TelegramID     *int64
	DiscordWebhook *string
}

type UserSummary struct {
	Username               string
	DataLimit              *int64
	Expire                 *int64
	Proxies                []string // protocol names present, e.g. ["vless", "vmess"]
	HasNextPlan            bool
	DataLimitResetStrategy string
}

type Dispatcher struct {
	flags      NotifyFlags
	settingsFn SettingsFunc
	telegram   *telegram.Sender
	discord    *discord.Sender
	logger     *slog.Logger
}

func New(flags NotifyFlags, settingsFn SettingsFunc, tg *telegram.Sender, dc *discord.Sender, logger *slog.Logger) *Dispatcher {
	return &Dispatcher{flags: flags, settingsFn: settingsFn, telegram: tg, discord: dc, logger: logger}
}

// resolve fetches the current settings and builds the telegram.Config for
// one notification category - shared setup for every dispatch method
// below. Returns ok=false (nothing to send) on a settings-read failure,
// logging the error - the one path that can't be per-recipient like
// telegram.Sender/discord.Sender's own failure isolation, since without
// settings there's no recipient to try.
//
// The category's own topic id (if the admin has set one up via POST
// /api/settings/integrations/telegram-topics) overrides the single global
// TelegramLoggerTopicID - a category with no topic of its own still falls
// back to that global one (or the group's General topic if neither is
// set), so a fresh integration with no topics configured yet behaves
// exactly as it did before this field existed.
func (d *Dispatcher) resolve(ctx context.Context, category string) (integrationsettings.Values, telegram.Config, bool) {
	vals, err := d.settingsFn(ctx)
	if err != nil {
		d.logger.Warn("report: could not resolve integration settings, dropping notification", "error", err)
		return integrationsettings.Values{}, telegram.Config{}, false
	}
	topicID := vals.TelegramLoggerTopicID
	if id, ok := vals.TelegramTopicIDs[category]; ok {
		topicID = id
	}
	cfg := telegram.Config{
		APIToken:        vals.TelegramAPIToken,
		AdminIDs:        vals.TelegramAdminIDs,
		LoggerChannelID: vals.TelegramLoggerChannelID,
		LoggerTopicID:   topicID,
		ProxyURL:        vals.TelegramProxyURL,
	}
	return vals, cfg, true
}

func dmChatID(userAdmin *AdminRef) *int64 {
	if userAdmin != nil {
		return userAdmin.TelegramID
	}
	return nil
}

func adminWebhook(userAdmin *AdminRef) *string {
	if userAdmin != nil {
		return userAdmin.DiscordWebhook
	}
	return nil
}

func belongsTo(userAdmin *AdminRef) *string {
	if userAdmin == nil {
		return nil
	}
	return &userAdmin.Username
}

func (d *Dispatcher) StatusChange(ctx context.Context, username, status string, userAdmin *AdminRef) {
	if !d.flags.StatusChange {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryStatusChange)
	if !ok {
		return
	}
	text := telegram.StatusChangeMessage(username, status, belongsTo(userAdmin))
	d.telegram.Report(ctx, tgCfg, text, dmChatID(userAdmin), d.logger)

	payload := discord.StatusChangePayload(username, status, belongsTo(userAdmin))
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, adminWebhook(userAdmin), d.logger)
}

func (d *Dispatcher) UserCreated(ctx context.Context, user UserSummary, byUsername string, userAdmin *AdminRef) {
	if !d.flags.UserCreated {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryUserCreated)
	if !ok {
		return
	}
	text := telegram.NewUserMessage(user.Username, byUsername, user.DataLimit, user.Expire, user.Proxies, user.HasNextPlan, user.DataLimitResetStrategy, belongsTo(userAdmin))
	d.telegram.Report(ctx, tgCfg, text, dmChatID(userAdmin), d.logger)

	payload := discord.NewUserPayload(user.Username, byUsername, user.DataLimit, user.Expire, user.Proxies, user.HasNextPlan, user.DataLimitResetStrategy, belongsTo(userAdmin))
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, adminWebhook(userAdmin), d.logger)
}

func (d *Dispatcher) UserUpdated(ctx context.Context, user UserSummary, byUsername string, userAdmin *AdminRef) {
	if !d.flags.UserUpdated {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryUserUpdated)
	if !ok {
		return
	}
	text := telegram.ModifiedMessage(user.Username, byUsername, user.DataLimit, user.Expire, user.Proxies, user.HasNextPlan, user.DataLimitResetStrategy, belongsTo(userAdmin))
	d.telegram.Report(ctx, tgCfg, text, dmChatID(userAdmin), d.logger)

	payload := discord.ModifiedPayload(user.Username, byUsername, user.DataLimit, user.Expire, user.Proxies, user.HasNextPlan, user.DataLimitResetStrategy, belongsTo(userAdmin))
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, adminWebhook(userAdmin), d.logger)
}

func (d *Dispatcher) UserDeleted(ctx context.Context, username, byUsername string, userAdmin *AdminRef) {
	if !d.flags.UserDeleted {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryUserDeleted)
	if !ok {
		return
	}
	text := telegram.DeletedMessage(username, byUsername, belongsTo(userAdmin))
	d.telegram.Report(ctx, tgCfg, text, dmChatID(userAdmin), d.logger)

	payload := discord.DeletedPayload(username, byUsername, belongsTo(userAdmin))
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, adminWebhook(userAdmin), d.logger)
}

func (d *Dispatcher) UserDataUsageReset(ctx context.Context, username, byUsername string, userAdmin *AdminRef) {
	if !d.flags.UserDataUsedReset {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryUserDataUsedReset)
	if !ok {
		return
	}
	text := telegram.UsageResetMessage(username, byUsername, belongsTo(userAdmin))
	d.telegram.Report(ctx, tgCfg, text, dmChatID(userAdmin), d.logger)

	payload := discord.UsageResetPayload(username, byUsername, belongsTo(userAdmin))
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, adminWebhook(userAdmin), d.logger)
}

func (d *Dispatcher) UserDataResetByNext(ctx context.Context, user UserSummary, userAdmin *AdminRef) {
	if !d.flags.UserDataUsedReset {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryUserDataUsedReset)
	if !ok {
		return
	}
	text := telegram.DataResetByNextMessage(user.Username, user.DataLimit, user.Expire)
	d.telegram.Report(ctx, tgCfg, text, dmChatID(userAdmin), d.logger)

	payload := discord.DataResetByNextPayload(user.Username, user.DataLimit, user.Expire)
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, adminWebhook(userAdmin), d.logger)
}

func (d *Dispatcher) UserSubscriptionRevoked(ctx context.Context, username, byUsername string, userAdmin *AdminRef) {
	if !d.flags.UserSubRevoked {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryUserSubRevoked)
	if !ok {
		return
	}
	text := telegram.SubscriptionRevokedMessage(username, byUsername, belongsTo(userAdmin))
	d.telegram.Report(ctx, tgCfg, text, dmChatID(userAdmin), d.logger)

	payload := discord.SubscriptionRevokedPayload(username, byUsername, belongsTo(userAdmin))
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, adminWebhook(userAdmin), d.logger)
}

// InfraAlert reports a WireGuard tunnel or external relay changing
// availability - fleet-wide, like Login, with no owning-admin/DM routing.
// InfraAlert reports a WireGuard tunnel or external relay's up<->down
// transition. domain (tunnelhealth's own "tunnel"/"exit"/"node" fault
// classification, empty for a relay or a recovery) and downFor (the exact
// time it was down, only meaningful on a recovery) are forwarded as-is to
// both integrations - see telegram.InfraAlertMessage's own doc comment for
// what each renders as.
func (d *Dispatcher) InfraAlert(ctx context.Context, kind, name, detail string, up bool, domain string, downFor time.Duration) {
	if !d.flags.InfraAlert {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryInfraAlert)
	if !ok {
		return
	}
	text := telegram.InfraAlertMessage(kind, name, detail, up, domain, downFor)
	d.telegram.Report(ctx, tgCfg, text, nil, d.logger)

	payload := discord.InfraAlertPayload(kind, name, detail, up, domain, downFor)
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, nil, d.logger)
}

// TopicRequest is one forum topic CreateTopics should create.
type TopicRequest struct {
	Category string
	Name     string
}

// CreateTopics creates one forum topic per entry in chatID (a supergroup
// with Topics/forum mode enabled, the bot added as an admin with "Manage
// Topics" - see telegram.Sender.CreateForumTopic for what fails without
// that) and returns the created thread ids keyed by category, plus any
// per-category errors. Partial success is expected and handled by the
// caller (handleSetupTelegramTopics) saving whatever did succeed rather
// than discarding it over one failure.
//
// Calls are spaced out, not fired concurrently: Telegram rate-limits
// createForumTopic per chat, and a setup action run once by an admin is not
// a place worth racing against that limit for a bit of speed.
func (d *Dispatcher) CreateTopics(ctx context.Context, chatID int64, topics []TopicRequest) (map[string]int64, map[string]string) {
	vals, err := d.settingsFn(ctx)
	if err != nil {
		return nil, map[string]string{"*": err.Error()}
	}
	cfg := telegram.Config{APIToken: vals.TelegramAPIToken, ProxyURL: vals.TelegramProxyURL}

	created := make(map[string]int64, len(topics))
	errs := make(map[string]string)
	for i, t := range topics {
		if i > 0 {
			select {
			case <-ctx.Done():
				errs[t.Category] = ctx.Err().Error()
				continue
			case <-time.After(1200 * time.Millisecond):
			}
		}
		id, err := d.telegram.CreateForumTopic(ctx, cfg, chatID, t.Name)
		if err != nil {
			errs[t.Category] = err.Error()
			continue
		}
		created[t.Category] = id
	}
	return created, errs
}

// Login has no owning-admin concept - matches Python's report_login, which
// always sends with admin_webhook=None and no DM.
func (d *Dispatcher) Login(ctx context.Context, username, clientIP, status string) {
	if !d.flags.Login {
		return
	}
	vals, tgCfg, ok := d.resolve(ctx, CategoryLogin)
	if !ok {
		return
	}
	text := telegram.LoginMessage(username, clientIP, status)
	d.telegram.Report(ctx, tgCfg, text, nil, d.logger)

	payload := discord.LoginPayload(username, clientIP, status)
	d.discord.Send(ctx, payload, vals.DiscordWebhookURL, nil, d.logger)
}
