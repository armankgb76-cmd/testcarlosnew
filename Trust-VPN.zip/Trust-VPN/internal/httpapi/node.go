package httpapi

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"

	"github.com/your-org/trust-vpn/internal/certs"
	"github.com/your-org/trust-vpn/internal/db/generated"
)

// generateReportSecret mirrors cmd/panel/main.go's ensureJWTSecret pattern
// (crypto/rand + hex) for the bearer token a node presents on every push -
// see migration 00006's doc comment.
func generateReportSecret() (string, error) {
	raw := make([]byte, 32)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	return hex.EncodeToString(raw), nil
}

// defaultNodePort/defaultNodeAPIPort mirror NodeCreate's own defaults on
// the real panel - a client that posts only {name, address} (the
// documented minimal body) must succeed there, so port/api_port cannot be
// required here either.
const (
	defaultNodePort    = 62050
	defaultNodeAPIPort = 62051
)

type nodeCreateRequest struct {
	Name             string   `json:"name" binding:"required"`
	Address          string   `json:"address" binding:"required"`
	Port             int32    `json:"port"`
	APIPort          int32    `json:"api_port"`
	UsageCoefficient *float64 `json:"usage_coefficient"`
	// PanelURL is optional and used for nothing but embedding in the setup
	// blob below - the admin already knows how this node should reach the
	// panel (an internal IP, a specific scheme/port), so there's no reason
	// to guess it. Left empty, the blob just omits panel_url and the node
	// falls back to its own PANEL_URL env var, same as before this existed.
	PanelURL string `json:"panel_url"`

	// The node's profile - see nodeProfile. All optional; absent, null and
	// empty all mean "same as every other node".
	InboundTags   tagsPatch                   `json:"inbound_tags"`
	ListenPorts   portsPatch                  `json:"listen_ports"`
	CoreOverrides patchField[json.RawMessage] `json:"core_overrides"`

	// Capacity is the number of open client connections that mean 100% load for
	// this node; absent or null means "use the panel default".
	Capacity capacityPatch `json:"capacity"`
}

// maxNodeCapacity bounds nodes.capacity: far above any real node, and well
// inside the INTEGER column.
const maxNodeCapacity = 10_000_000

// capacityPatch is a request's node capacity: absent, null (clear it), or a
// whole number of connections in 1..maxNodeCapacity.
type capacityPatch struct{ patchField[int64] }

func (p *capacityPatch) UnmarshalJSON(b []byte) error {
	return p.decode(b, "capacity must be a whole number or null")
}

// column validates the patch and returns the value to store (NULL when it is
// null or absent). The string is a 422 message, empty when fine.
func (p capacityPatch) column() (pgtype.Int4, string) {
	if !p.Set || p.Null {
		return pgtype.Int4{}, ""
	}
	if p.Value < 1 || p.Value > maxNodeCapacity {
		return pgtype.Int4{}, fmt.Sprintf("capacity must be between 1 and %d, or null to use the panel default", maxNodeCapacity)
	}
	return pgtype.Int4{Int32: int32(p.Value), Valid: true}, ""
}

// nodeSetupBlob is everything cmd/node needs to trust and reach the panel,
// bundled into one value - see handleCreateNode's own doc comment on why
// this replaced four separately-copied fields. Field names are deliberately
// short (not "certificate"/"report_secret") since this is the wire shape a
// human pastes as one blob, not a browsable API response - keeping it small
// keeps the copy-pasted text itself shorter.
type nodeSetupBlob struct {
	Cert     string `json:"cert"`
	Key      string `json:"key"`
	CA       string `json:"ca"`
	Secret   string `json:"secret"`
	PanelURL string `json:"panel_url,omitempty"`
}

// buildNodeSetupBlob base64-encodes a compact JSON envelope of everything a
// node needs to bootstrap itself - see cmd/node/main.go's NODE_SETUP_BLOB
// consumer, the other half of this pair.
func buildNodeSetupBlob(cert, key, ca, secret, panelURL string) (string, error) {
	raw, err := json.Marshal(nodeSetupBlob{Cert: cert, Key: key, CA: ca, Secret: secret, PanelURL: panelURL})
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(raw), nil
}

// nodeDTO mirrors app/models/node.py's NodeResponse. xray_version and
// message are nullable there but always present - a monitoring client
// reads message to find out WHY a node isn't connected, and omitting the
// key entirely turns that into a KeyError instead of a null.
type nodeDTO struct {
	ID               int32   `json:"id"`
	Name             string  `json:"name"`
	Address          string  `json:"address"`
	Port             int32   `json:"port"`
	APIPort          int32   `json:"api_port"`
	XrayVersion      *string `json:"xray_version"`
	Status           string  `json:"status"`
	Message          *string `json:"message"`
	UsageCoefficient float64 `json:"usage_coefficient"`
	// Capacity is how many open client connections read as 100% load on this
	// node; null means the panel-wide default (CONFIG_LOAD_CAPACITY) applies.
	Capacity *int32 `json:"capacity"`
	// The node's profile, each omitted while it is the default (see
	// nodeProfile), so a node nobody customised serializes as it always did.
	InboundTags   []string        `json:"inbound_tags,omitempty"`
	ListenPorts   []int32         `json:"listen_ports,omitempty"`
	CoreOverrides json.RawMessage `json:"core_overrides,omitempty"`
}

func toNodeDTO(n generated.Node) nodeDTO {
	dto := nodeDTO{
		ID: n.ID, Name: n.Name, Address: n.Address, Port: n.Port, APIPort: n.ApiPort,
		Status: n.Status, UsageCoefficient: n.UsageCoefficient, Capacity: pgInt4ToPtr(n.Capacity),
	}
	if n.XrayVersion.Valid {
		v := n.XrayVersion.String
		dto.XrayVersion = &v
	}
	if n.Message.Valid {
		m := n.Message.String
		dto.Message = &m
	}
	if len(n.InboundTags) > 0 {
		dto.InboundTags = n.InboundTags
	}
	if len(n.ListenPorts) > 0 {
		dto.ListenPorts = n.ListenPorts
	}
	if ov, err := parseCoreOverrides(n.CoreOverrides); err == nil && !ov.isZero() {
		dto.CoreOverrides = n.CoreOverrides
	}
	return dto
}

// handleCreateNode implements POST /api/node (sudo only). It issues the new
// node a real leaf certificate signed by the panel's own CA (the
// self-signed CN="Trust" cert generated into the `tls` table, which
// doubles as this CA since it was generated with IsCA:true). The response carries
// everything needed to bring the node online: its own cert+key and the CA
// cert, so the node can require and verify the panel's client certificate
// too, instead of trusting whatever connects.
//
// Provisioning used to mean copying four separate values (cert, key, ca,
// report_secret) into three files plus two env vars on the node server -
// the response now also bundles all of it into one base64 blob
// (setup_blob) the admin pastes as a single NODE_SETUP_BLOB value; the node
// writes its own files out and starts. Port/listen-address settings are
// deliberately NOT part of the blob - those are ordinary node-local config
// the admin still sets separately (NODE_LISTEN_ADDR etc.), not identity or
// trust material.
func (h *Handler) handleCreateNode(c *gin.Context) {
	var req nodeCreateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": err.Error()})
		return
	}
	usageCoefficient := 1.0
	if req.UsageCoefficient != nil {
		usageCoefficient = *req.UsageCoefficient
	}
	if req.Port == 0 {
		req.Port = defaultNodePort
	}
	if req.APIPort == 0 {
		req.APIPort = defaultNodeAPIPort
	}

	capacity, msg := req.Capacity.column()
	if msg != "" {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": msg})
		return
	}

	ctx := c.Request.Context()
	profile, msg, err := h.resolveNodeProfile(ctx, nodeProfileFields{overrides: emptyCoreOverridesJSON},
		req.InboundTags, req.ListenPorts, req.CoreOverrides)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not validate the node profile"})
		return
	}
	if msg != "" {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": msg})
		return
	}

	ca, err := h.store.Queries.GetTLS(ctx)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not load the Trust CA"})
		return
	}
	caKey, err := certs.ParseRSAPrivateKeyPEM(ca.Key)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not read the Trust CA key"})
		return
	}
	nodeCert, err := certs.SignNodeCert(req.Name, ca.Certificate, caKey)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not issue a certificate for this node"})
		return
	}
	reportSecret, err := generateReportSecret()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not generate a report secret for this node"})
		return
	}

	node, err := h.store.Queries.CreateNode(ctx, generated.CreateNodeParams{
		Name: req.Name, Address: req.Address, Port: req.Port, ApiPort: req.APIPort, UsageCoefficient: usageCoefficient,
		ReportSecret: pgtype.Text{String: reportSecret, Valid: true},
		InboundTags:  profile.tags, ListenPorts: profile.ports, CoreOverrides: profile.overrides,
		Capacity: capacity,
	})
	if err != nil {
		if isUniqueViolation(err) {
			c.JSON(http.StatusConflict, gin.H{"detail": "A node with this name already exists"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not create node"})
		return
	}

	setupBlob, err := buildNodeSetupBlob(nodeCert.CertPEM, nodeCert.KeyPEM, ca.Certificate, reportSecret, req.PanelURL)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not build the setup blob"})
		return
	}

	// Every value below - the blob and its four raw components alike - is
	// returned here and only here, never retrievable again through any
	// later GET. setup_blob is what the dashboard's reveal panel shows by
	// default (paste once into NODE_SETUP_BLOB, see cmd/node/main.go); the
	// four raw fields stay in the response for a manual/scripted setup or
	// for inspecting what's actually inside the blob, not because the
	// dashboard still shows them as the primary flow.
	//
	// The node's own fields are emitted at the TOP level, matching the real
	// panel's NodeResponse - a client doing resp["id"] right after creating
	// a node must find it there. The nested "node" key is kept as well so
	// this panel's own dashboard keeps working; extra keys break nobody.
	merged, err := mergeJSONObjects(toNodeDTO(node), gin.H{
		"node":           toNodeDTO(node),
		"setup_blob":     setupBlob,
		"certificate":    nodeCert.CertPEM,
		"key":            nodeCert.KeyPEM,
		"ca_certificate": ca.Certificate,
		"report_secret":  reportSecret,
	})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not build the node response"})
		return
	}
	c.Data(http.StatusOK, "application/json; charset=utf-8", merged)
}

// nodeUpdateRequest is fully optional, field by field: the real panel's
// NodeModify has no required fields at all, so PUT {"usage_coefficient":2}
// or PUT {"status":"disabled"} - the documented way to disable a node - has
// to work without resending the whole object.
type nodeUpdateRequest struct {
	Name             *string  `json:"name"`
	Address          *string  `json:"address"`
	Port             *int32   `json:"port"`
	APIPort          *int32   `json:"api_port"`
	UsageCoefficient *float64 `json:"usage_coefficient"`
	// Status is the real panel's own spelling ("disabled" switches a node
	// off, anything else puts it back to connecting); Disabled is this
	// panel's older boolean, kept working for its own dashboard.
	Status   *string `json:"status"`
	Disabled *bool   `json:"disabled"`

	// Profile fields, see nodeCreateRequest. Absent leaves the stored value
	// alone; null or empty clears it back to the default.
	InboundTags   tagsPatch                   `json:"inbound_tags"`
	ListenPorts   portsPatch                  `json:"listen_ports"`
	CoreOverrides patchField[json.RawMessage] `json:"core_overrides"`

	// Capacity: absent leaves the stored value alone, null clears it back to the
	// panel default, a number sets it (1..10000000).
	Capacity capacityPatch `json:"capacity"`
}

// onlyCapacity reports a request that changes nothing but the capacity.
func (r nodeUpdateRequest) onlyCapacity() bool {
	return r.Capacity.Set &&
		r.Name == nil && r.Address == nil && r.Port == nil && r.APIPort == nil &&
		r.UsageCoefficient == nil && r.Status == nil && r.Disabled == nil &&
		!r.InboundTags.Set && !r.ListenPorts.Set && !r.CoreOverrides.Set
}

// handleUpdateNode implements PUT /api/node/:id (sudo only). A full-field
// update - the dashboard's edit form always sends the whole node back, not
// a partial patch - except usage_coefficient/disabled, which stay
// unchanged when omitted (see UpdateNode's own doc comment).
func (h *Handler) handleUpdateNode(c *gin.Context) {
	id, err := parseIDParam(c, "id")
	if err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": "invalid node id"})
		return
	}
	var req nodeUpdateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": err.Error()})
		return
	}

	capacity, msg := req.Capacity.column()
	if msg != "" {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": msg})
		return
	}

	ctx := c.Request.Context()
	if req.onlyCapacity() {
		// Its own statement: UpdateNode names the profile columns in its SET
		// list, which would bump the node-config version for a change that no
		// node needs to hear about.
		node, err := h.store.Queries.SetNodeCapacity(ctx, generated.SetNodeCapacityParams{ID: id, Capacity: capacity})
		if err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				c.JSON(http.StatusNotFound, gin.H{"detail": "Node not found"})
				return
			}
			c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not update node"})
			return
		}
		c.JSON(http.StatusOK, toNodeDTO(node))
		return
	}

	// Every field is optional, so the stored row is the base and only what
	// the caller actually sent is overlaid onto it.
	current, err := h.store.Queries.GetNodeByID(ctx, id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"detail": "Node not found"})
		return
	}
	name, address, port, apiPort := current.Name, current.Address, current.Port, current.ApiPort
	if req.Name != nil {
		name = *req.Name
	}
	if req.Address != nil {
		address = *req.Address
	}
	if req.Port != nil {
		port = *req.Port
	}
	if req.APIPort != nil {
		apiPort = *req.APIPort
	}

	profile, msg, err := h.resolveNodeProfile(ctx, profileFieldsFromNode(current),
		req.InboundTags, req.ListenPorts, req.CoreOverrides)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not validate the node profile"})
		return
	}
	if msg != "" {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": msg})
		return
	}

	var usageCoefficient pgtype.Float8
	if req.UsageCoefficient != nil {
		usageCoefficient = pgtype.Float8{Float64: *req.UsageCoefficient, Valid: true}
	}
	var disabled pgtype.Bool
	if req.Disabled != nil {
		disabled = pgtype.Bool{Bool: *req.Disabled, Valid: true}
	}
	// status wins over disabled when both are sent - it's the documented
	// field, and the two can't disagree without the caller contradicting
	// itself.
	if req.Status != nil {
		disabled = pgtype.Bool{Bool: *req.Status == "disabled", Valid: true}
	}

	node, err := h.store.Queries.UpdateNode(ctx, generated.UpdateNodeParams{
		ID: id, Name: name, Address: address, Port: port, ApiPort: apiPort,
		UsageCoefficient: usageCoefficient, Disabled: disabled,
		InboundTags: profile.tags, ListenPorts: profile.ports, CoreOverrides: profile.overrides,
		SetCapacity: req.Capacity.Set, Capacity: capacity,
	})
	if err != nil {
		if isUniqueViolation(err) {
			c.JSON(http.StatusConflict, gin.H{"detail": "A node with this name already exists"})
			return
		}
		c.JSON(http.StatusNotFound, gin.H{"detail": "Node not found"})
		return
	}
	c.JSON(http.StatusOK, toNodeDTO(node))
}

// handleListNodes implements GET /api/nodes (sudo only).
func (h *Handler) handleListNodes(c *gin.Context) {
	nodes, err := h.store.Queries.ListNodes(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not list nodes"})
		return
	}
	out := make([]nodeDTO, 0, len(nodes))
	for _, n := range nodes {
		out = append(out, toNodeDTO(n))
	}
	c.JSON(http.StatusOK, out)
}

// handleGetNode implements GET /api/node/:id (sudo only).
func (h *Handler) handleGetNode(c *gin.Context) {
	id, err := parseIDParam(c, "id")
	if err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": "invalid node id"})
		return
	}
	node, err := h.store.Queries.GetNodeByID(c.Request.Context(), id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"detail": "Node not found"})
		return
	}
	c.JSON(http.StatusOK, toNodeDTO(node))
}

// handleDeleteNode implements DELETE /api/node/:id (sudo only).
func (h *Handler) handleDeleteNode(c *gin.Context) {
	id, err := parseIDParam(c, "id")
	if err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": "invalid node id"})
		return
	}
	ctx := c.Request.Context()
	// An id that doesn't exist is a 404, not a success: a cleanup script
	// that distinguishes "already gone" from "I just deleted it" (and one
	// verifying a typo'd id) gets a wrong answer otherwise.
	if _, err := h.store.Queries.GetNodeByID(ctx, id); err != nil {
		c.JSON(http.StatusNotFound, gin.H{"detail": "Node not found"})
		return
	}
	if err := h.store.Queries.DeleteNode(ctx, id); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not delete node"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"detail": "Node removed successfully"})
}

// nodeUsageDTO mirrors app/models/node.py's NodeUsageResponse - node_id is
// nullable there because the list always leads with a "Master" row for the
// panel's own core.
type nodeUsageDTO struct {
	NodeID   *int32 `json:"node_id"`
	NodeName string `json:"node_name"`
	Uplink   int64  `json:"uplink"`
	Downlink int64  `json:"downlink"`
}

// handleGetNodesUsage implements GET /api/nodes/usage?start=&end= (sudo
// only) - RFC3339 bounds, defaulting to the trailing 30 days when omitted.
// Every node gets a row even with zero traffic in the window (see
// GetNodesUsage's own doc comment).
func (h *Handler) handleGetNodesUsage(c *gin.Context) {
	// Same ?start=/?end= contract as every other usage endpoint: several
	// ISO spellings accepted, an inverted range rejected outright rather
	// than silently answered with the 30-day default.
	start, end, ok := usageWindow(c)
	if !ok {
		return
	}

	rows, err := h.store.Queries.GetNodesUsage(c.Request.Context(), generated.GetNodesUsageParams{
		CreatedAt: timestamptzFromTime(start), CreatedAt_2: timestamptzFromTime(end),
	})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not read node usage"})
		return
	}
	// The real panel's list always leads with a "Master" row for the
	// panel's own core. There is no local core here (this rewrite's node
	// agent is always a separate process), so its totals are genuinely
	// zero - but the row itself has to exist, because clients locate the
	// series with usages[0] or by matching node_id === null.
	out := make([]nodeUsageDTO, 0, len(rows)+1)
	out = append(out, nodeUsageDTO{NodeID: nil, NodeName: "Master"})
	for _, r := range rows {
		id := r.NodeID
		out = append(out, nodeUsageDTO{NodeID: &id, NodeName: r.NodeName, Uplink: r.Uplink, Downlink: r.Downlink})
	}
	c.JSON(http.StatusOK, gin.H{"usages": out})
}
