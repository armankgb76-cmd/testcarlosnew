package httpapi

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"

	"github.com/your-org/trust-vpn/internal/auth"
	"github.com/your-org/trust-vpn/internal/certs"
	"github.com/your-org/trust-vpn/internal/db/generated"
	"github.com/your-org/trust-vpn/internal/resellerapi"
)

// handleListInbounds implements GET /api/inbounds, grouped by protocol like
// the current system.py's GET /api/inbounds (there, read live from the
// parsed xray/sing-box config; here, from the inbounds table until the
// node-agent phase syncs it from a live proxy core config for real - see
// 00002_inbound_protocol.sql).
// proxyInboundDTO mirrors the panel API's ProxyInbound model exactly - all
// five fields, always present. The earlier shape here was a bare tag
// string per entry, which is a real incompatibility rather than a
// simplification: every external API client iterates this map and
// reads inbound["tag"] (plus port/network to build a config), and a string
// is not indexable, so such a client sees zero usable inbounds. One real
// reseller bot's symptom for that is refusing to sync "to avoid deleting
// tags by mistake" - it found no tags it could parse.
type proxyInboundDTO struct {
	Tag      string `json:"tag"`
	Protocol string `json:"protocol"`
	Network  string `json:"network"`
	TLS      string `json:"tls"`
	Port     int32  `json:"port"`
	// Ports is every distinct port of the inbound's enabled hosts, ascending
	// (always an array, empty when there are none). Port stays the primary
	// host's alone: the panel API's model has no such field, so the one
	// every client reads must not change meaning.
	Ports []int `json:"ports"`
}

func (h *Handler) handleListInbounds(c *gin.Context) {
	ctx := c.Request.Context()
	rows, err := h.store.Queries.ListInboundsWithPort(ctx)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not list inbounds"})
		return
	}

	byTag := make(map[string]proxyInboundDTO, len(rows))
	tagsByProtocol := map[string][]string{}
	for _, r := range rows {
		byTag[r.Tag] = proxyInboundDTO{
			Tag: r.Tag, Protocol: r.Protocol, Network: r.Network,
			// The real panel calls this field "tls" and puts the security
			// mode in it ("none"/"tls"/"reality"), which is what this
			// column already holds.
			TLS:   r.Security,
			Port:  r.Port.Int32,
			Ports: validHostPorts(r.Ports),
		}
		tagsByProtocol[r.Protocol] = append(tagsByProtocol[r.Protocol], r.Tag)
	}

	// the reseller API inbound filtering (app/resellerapi/manager.py's get_configs, called
	// from app/routers/system.py's get_inbounds): a reseller only sees the
	// inbounds their external bot allows. Sudo always sees everything -
	// the reseller API is never even called for a sudo admin. It filters tags, so it
	// runs on the tag map and the result is expanded back into objects.
	identity := auth.CurrentIdentity(c)
	if !identity.IsSudo {
		settings, _, err := h.resolveIntegrationSettings(c)
		if err == nil {
			if filtered := h.resellerapi.GetConfigs(ctx, resellerapi.Config{Secret: settings.ResellerApiSecret, URL: settings.ResellerApiUrl}, identity.Username, tagsByProtocol); len(filtered) > 0 {
				tagsByProtocol = filtered
			}
		}
	}

	out := make(map[string][]proxyInboundDTO, len(tagsByProtocol))
	for protocol, tags := range tagsByProtocol {
		entries := make([]proxyInboundDTO, 0, len(tags))
		for _, tag := range tags {
			if entry, ok := byTag[tag]; ok {
				entries = append(entries, entry)
				continue
			}
			// A tag the reseller API returned that this panel doesn't have: keep it
			// visible rather than dropping it silently, with the protocol
			// it was filed under.
			entries = append(entries, proxyInboundDTO{Tag: tag, Protocol: protocol, Network: "tcp", TLS: "none", Ports: []int{}})
		}
		out[protocol] = entries
	}

	c.JSON(http.StatusOK, out)
}

// inboundDetailDTO is the full-fidelity shape a real "Inbounds" management
// page needs (tag/protocol/network/security/reality fields) - deliberately
// a NEW response shape on a NEW route rather than changing GET /api/inbounds
// itself, which stays the simple map[protocol][]tag shape the the reseller API
// filtering logic and InboundsPicker.tsx already depend on.
type inboundDetailDTO struct {
	Tag        string `json:"tag"`
	Protocol   string `json:"protocol"`
	Network    string `json:"network"`
	HeaderType string `json:"header_type"`

	Security          string   `json:"security"`
	RealityPrivateKey string   `json:"reality_private_key,omitempty"`
	RealityShortIDs   []string `json:"reality_short_ids,omitempty"`
	RealityServerName string   `json:"reality_server_name,omitempty"`
	RealityServerPort int32    `json:"reality_server_port,omitempty"`

	// TLS* is only meaningful when Security is "tls" - a real customer-
	// facing certificate/key pair (plain PEM text, same no-encryption-at-
	// rest convention RealityPrivateKey already uses), NOT the panel's own
	// CA in the `tls` table used for node mTLS. An inbound with
	// Security="tls" and an empty TLSCertificate/TLSKey stays out of
	// automatic node sync until both are filled in - see
	// ListAutoSyncInbounds's own doc comment.
	TLSCertificate string `json:"tls_certificate,omitempty"`
	TLSKey         string `json:"tls_key,omitempty"`
	TLSServerName  string `json:"tls_server_name,omitempty"`

	// Hysteria2ObfsPassword/UpMbps/DownMbps only apply to protocol="hysteria2";
	// CongestionControl/ZeroRTTHandshake only to protocol="tuic". Both
	// protocols are QUIC-based and TLS-mandatory - see
	// internal/nodecore/hysteria2 and internal/nodecore/tuic's own doc
	// comments - so unlike the TCP-family fields above, none of these six
	// are meaningful together with reality_*/network/header_type.
	Hysteria2ObfsPassword string `json:"hysteria2_obfs_password,omitempty"`
	UpMbps                int32  `json:"up_mbps,omitempty"`
	DownMbps              int32  `json:"down_mbps,omitempty"`
	CongestionControl     string `json:"congestion_control,omitempty"`
	ZeroRTTHandshake      bool   `json:"zero_rtt_handshake,omitempty"`

	// SnellPSK/SnellV6Mode only apply to protocol="snell" - Snell has no TLS
	// of its own, so unlike every field above (TCP-family or QUIC-family),
	// neither is meaningful together with security/reality_*/tls_*. See
	// internal/nodecore/snell's own doc comment for why SnellPSK is a
	// separate, inbound-level secret from any one user's own credential.
	SnellPSK    string `json:"snell_psk,omitempty"`
	SnellV6Mode string `json:"snell_v6_mode,omitempty"`

	// HysteriaObfsPassword only applies to protocol="hysteria" (v1, not
	// hysteria2) - a single shared XPlus obfuscation password, simpler than
	// hysteria2's own salamander/gecko obfs. See internal/nodecore/hysteria's
	// own doc comment.
	HysteriaObfsPassword string `json:"hysteria_obfs_password,omitempty"`

	// ShadowTLSInnerMethod/ShadowTLSInnerPassword only apply to
	// protocol="shadowtls" - the embedded inner shadowsocks-2022 layer's
	// inbound-level method+PSK, shared by every user of the inbound (each
	// user's own ShadowTLS password lives in proxies.settings jsonb
	// instead, same split as snell_psk/UserKey above). See
	// internal/nodecore/shadowtls's own doc comment.
	ShadowTLSInnerMethod   string `json:"shadowtls_inner_method,omitempty"`
	ShadowTLSInnerPassword string `json:"shadowtls_inner_password,omitempty"`
}

func toInboundDetailDTO(in generated.Inbound) inboundDetailDTO {
	// pgtype.Text/Int4's own zero value is "" / 0 when !Valid, exactly the
	// "unset" wire value this DTO wants - no helper needed.
	return inboundDetailDTO{
		Tag: in.Tag, Protocol: in.Protocol, Network: in.Network, HeaderType: in.HeaderType.String,
		Security:               in.Security,
		RealityPrivateKey:      in.RealityPrivateKey.String,
		RealityShortIDs:        in.RealityShortIds,
		RealityServerName:      in.RealityServerName.String,
		RealityServerPort:      in.RealityServerPort.Int32,
		TLSCertificate:         in.TlsCertificate.String,
		TLSKey:                 in.TlsKey.String,
		TLSServerName:          in.TlsServerName.String,
		Hysteria2ObfsPassword:  in.Hysteria2ObfsPassword.String,
		UpMbps:                 in.UpMbps.Int32,
		DownMbps:               in.DownMbps.Int32,
		CongestionControl:      in.CongestionControl.String,
		ZeroRTTHandshake:       in.ZeroRttHandshake,
		SnellPSK:               in.SnellPsk.String,
		SnellV6Mode:            in.SnellV6Mode.String,
		HysteriaObfsPassword:   in.HysteriaObfsPassword.String,
		ShadowTLSInnerMethod:   in.ShadowtlsInnerMethod.String,
		ShadowTLSInnerPassword: in.ShadowtlsInnerPassword.String,
	}
}

// handleListInboundsDetailed implements GET /api/inbounds/detail (sudo
// only) - the real list a dedicated Inbounds admin page renders, as opposed
// to handleListInbounds's simpler protocol-grouped tag list every admin can
// read for the user-create form's inbound picker.
func (h *Handler) handleListInboundsDetailed(c *gin.Context) {
	rows, err := h.store.Queries.ListInbounds(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "Could not list inbounds"})
		return
	}
	out := make([]inboundDetailDTO, 0, len(rows))
	for _, r := range rows {
		out = append(out, toInboundDetailDTO(r))
	}
	c.JSON(http.StatusOK, out)
}

// handleDeleteInbound implements DELETE /api/inbounds/:tag (sudo only).
func (h *Handler) handleDeleteInbound(c *gin.Context) {
	tag := c.Param("tag")
	ctx := c.Request.Context()

	if err := h.deleteInboundByTag(ctx, tag); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			c.JSON(http.StatusNotFound, gin.H{"detail": "Inbound not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"detail": err.Error()})
		return
	}
	if err := h.store.InvalidateNodeConfigPayload(ctx); err != nil {
		h.logger.Warn("invalidate node config cache", "error", err)
	}
	proxiesRemoved, err := h.pruneOrphanedProxies(ctx)
	if err != nil {
		h.logger.Warn("prune orphaned proxies", "error", err)
	}
	c.JSON(http.StatusOK, gin.H{"detail": "Inbound removed successfully", "orphaned_proxies_removed": proxiesRemoved})
}

// deleteInboundByTag is the real work behind DELETE /api/inbounds/:tag:
// remove the row (cascades to that inbound's hosts/exclusions/template-
// associations at the DB level, see DeleteInboundByTag's own doc comment)
// and invalidate the caches that would otherwise keep serving it until
// their TTL. Deliberately does NOT invalidate the node-config cache itself
// - callers that delete several tags in one pass (handleUpdateXrayConfig)
// only need to pay that one cost once, after the whole batch, not per tag.
func (h *Handler) deleteInboundByTag(ctx context.Context, tag string) error {
	inbound, err := h.store.Queries.GetInboundByTag(ctx, tag)
	if err != nil {
		return err
	}
	if err := h.store.Queries.DeleteInboundByTag(ctx, tag); err != nil {
		return fmt.Errorf("could not delete inbound %s: %w", tag, err)
	}
	if err := h.store.InvalidateInbound(ctx, tag, inbound.Protocol, nil); err != nil {
		return fmt.Errorf("could not invalidate inbound cache for %s: %w", tag, err)
	}
	return nil
}

type inboundSyncEntry struct {
	Tag        string `json:"tag" binding:"required"`
	Protocol   string `json:"protocol" binding:"required"`
	Network    string `json:"network"`     // tcp/ws/grpc/kcp/quic/splithttp/xhttp - defaults to "tcp"
	HeaderType string `json:"header_type"` // e.g. "http" for tcp obfuscation
	// Port, when a brand-new tag is created, is written straight onto its
	// default host instead of leaving it NULL (see createDefaultHost's own
	// doc comment on why a portless default host normally exists) - what
	// lets POST /api/inbounds (a direct, one-shot "add this protocol on
	// this port" creation, unlike this endpoint's own sync/upsert shape)
	// build a fully working inbound in a single call. Zero/omitted keeps
	// the original portless-default behavior; ignored entirely when the
	// tag already exists, matching upsert's own "don't touch an existing
	// host" rule.
	Port int32 `json:"port,omitempty"`

	Security          string   `json:"security"` // none/tls/reality - defaults to "none"
	RealityPrivateKey string   `json:"reality_private_key,omitempty"`
	RealityShortIDs   []string `json:"reality_short_ids,omitempty"`
	RealityServerName string   `json:"reality_server_name,omitempty"`
	RealityServerPort int32    `json:"reality_server_port,omitempty"`

	TLSCertificate string `json:"tls_certificate,omitempty"`
	TLSKey         string `json:"tls_key,omitempty"`
	TLSServerName  string `json:"tls_server_name,omitempty"`

	// See inboundDetailDTO's own doc comment on these same eight fields.
	Hysteria2ObfsPassword string `json:"hysteria2_obfs_password,omitempty"`
	UpMbps                int32  `json:"up_mbps,omitempty"`
	DownMbps              int32  `json:"down_mbps,omitempty"`
	CongestionControl     string `json:"congestion_control,omitempty"`
	ZeroRTTHandshake      bool   `json:"zero_rtt_handshake,omitempty"`
	SnellPSK              string `json:"snell_psk,omitempty"`
	SnellV6Mode           string `json:"snell_v6_mode,omitempty"`

	// See inboundDetailDTO's own doc comment on this field.
	HysteriaObfsPassword string `json:"hysteria_obfs_password,omitempty"`

	// See inboundDetailDTO's own doc comment on these two fields.
	ShadowTLSInnerMethod   string `json:"shadowtls_inner_method,omitempty"`
	ShadowTLSInnerPassword string `json:"shadowtls_inner_password,omitempty"`
}

// syncInboundEntries is the real work behind POST /api/inbounds/sync:
// upsert-by-tag, creating a default host (no real port yet) for any
// genuinely new tag. Extracted out of handleSyncInbounds so the
// Xray-config importer (internal/httpapi/xrayimport.go) can reuse the
// exact same write path instead of duplicating it - unlike that HTTP
// handler, this returns a plain Go error (an unknown-protocol entry is
// reported the same way any other failure is, via the returned error, not
// a distinct HTTP status - both callers already validate protocol values
// upstream of this function in their own way).
func (h *Handler) syncInboundEntries(ctx context.Context, entries []inboundSyncEntry) (created int, err error) {
	for _, e := range entries {
		if !proxyTypeValid(e.Protocol) {
			return created, &inboundValidationError{"unknown protocol: " + e.Protocol}
		}
		// hysteria2/tuic are QUIC-based and sing-box refuses to even start
		// one without TLS (C.ErrTLSRequired) - caught here as a clean 422
		// instead of surfacing later as every one of that inbound's users
		// failing to connect.
		// anytls joins this same check for the same reason as hysteria2/tuic
		// above (C.ErrTLSRequired at the sing-box level) - see
		// internal/nodecore/anytls's own doc comment on why TLS is mandatory
		// here rather than admin-optional like sing-box's own inbound. hysteria
		// (v1) joins it too - sing-box's own NewInbound returns C.ErrTLSRequired
		// for it exactly like hysteria2/tuic/anytls do.
		if (e.Protocol == "hysteria2" || e.Protocol == "tuic" || e.Protocol == "anytls" || e.Protocol == "hysteria") && e.Security != "tls" {
			return created, &inboundValidationError{"inbound " + e.Tag + ": security must be \"tls\" for protocol " + e.Protocol}
		}
		if e.Protocol == "tuic" && e.CongestionControl != "" && !validCongestionControl[e.CongestionControl] {
			return created, &inboundValidationError{"inbound " + e.Tag + ": invalid congestion_control " + e.CongestionControl}
		}
		// Unlike hysteria2 (defaults to BBR, up_mbps/down_mbps are just an
		// optional hint - see migration 00018's own comment), Hysteria v1 has
		// no congestion-control fallback and genuinely cannot function
		// without a declared bandwidth ceiling - sing-quic/hysteria.Service
		// divides by these to pace sends, so a missing value here is a
		// "connects but is unusably slow/broken" bug at runtime, not an
		// obviously-rejected request. Caught here as a clean 422 instead,
		// matching Core Config's own outbound-side requirement for the same
		// protocol.
		if e.Protocol == "hysteria" && (e.UpMbps <= 0 || e.DownMbps <= 0) {
			return created, &inboundValidationError{"inbound " + e.Tag + ": up_mbps and down_mbps must both be > 0 for protocol hysteria"}
		}
		if e.Protocol == "snell" {
			// sing-snell's own v6 server rejects a PSK outside this range
			// (see internal/nodecore/snell's own doc comment) - checked here
			// so a bad one is a clean 422, not a node that fails to start.
			if len(e.SnellPSK) < 12 || len(e.SnellPSK) > 255 {
				return created, &inboundValidationError{"inbound " + e.Tag + ": snell_psk must be 12-255 bytes"}
			}
			if e.SnellV6Mode != "" && !validSnellV6Modes[e.SnellV6Mode] {
				return created, &inboundValidationError{"inbound " + e.Tag + ": invalid snell_v6_mode " + e.SnellV6Mode}
			}
		}
		if e.Protocol == "shadowtls" {
			// See internal/nodecore/shadowtls's own doc comment for why
			// this protocol alone needs a second, inbound-level secret in
			// addition to each user's own ShadowTLS password - checked
			// here so a bad one is a clean 422, not a node that fails to
			// start.
			keyLen, ok := shadowTLSInnerKeyLength[e.ShadowTLSInnerMethod]
			if !ok {
				return created, &inboundValidationError{"inbound " + e.Tag + ": invalid shadowtls_inner_method " + e.ShadowTLSInnerMethod}
			}
			psk, err := base64.StdEncoding.DecodeString(e.ShadowTLSInnerPassword)
			if err != nil || len(psk) < keyLen {
				return created, &inboundValidationError{fmt.Sprintf("inbound %s: shadowtls_inner_password must be a base64-encoded key of at least %d bytes for method %s", e.Tag, keyLen, e.ShadowTLSInnerMethod)}
			}
		}
	}

	for _, e := range entries {
		network := e.Network
		if network == "" {
			network = "tcp"
		}
		security := e.Security
		if security == "" {
			security = "none"
		}

		var oldProtocol *string
		if existing, err := h.store.Queries.GetInboundByTag(ctx, e.Tag); err == nil {
			oldProtocol = &existing.Protocol
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return created, fmt.Errorf("could not sync inbound %s: %w", e.Tag, err)
		}

		row, err := h.store.Queries.UpsertInbound(ctx, generated.UpsertInboundParams{
			Tag: e.Tag, Protocol: e.Protocol, Network: network, HeaderType: textFromPtr(normalizeZeroString(&e.HeaderType)),
			Security:               security,
			RealityPrivateKey:      textFromPtr(normalizeZeroString(&e.RealityPrivateKey)),
			RealityShortIds:        e.RealityShortIDs,
			RealityServerName:      textFromPtr(normalizeZeroString(&e.RealityServerName)),
			RealityServerPort:      realityPortToPg(e.RealityServerPort),
			TlsCertificate:         textFromPtr(normalizeZeroString(&e.TLSCertificate)),
			TlsKey:                 textFromPtr(normalizeZeroString(&e.TLSKey)),
			TlsServerName:          textFromPtr(normalizeZeroString(&e.TLSServerName)),
			Hysteria2ObfsPassword:  textFromPtr(normalizeZeroString(&e.Hysteria2ObfsPassword)),
			UpMbps:                 pgInt4FromZero(e.UpMbps),
			DownMbps:               pgInt4FromZero(e.DownMbps),
			CongestionControl:      textFromPtr(normalizeZeroString(&e.CongestionControl)),
			ZeroRttHandshake:       e.ZeroRTTHandshake,
			SnellPsk:               textFromPtr(normalizeZeroString(&e.SnellPSK)),
			SnellV6Mode:            textFromPtr(normalizeZeroString(&e.SnellV6Mode)),
			HysteriaObfsPassword:   textFromPtr(normalizeZeroString(&e.HysteriaObfsPassword)),
			ShadowtlsInnerMethod:   textFromPtr(normalizeZeroString(&e.ShadowTLSInnerMethod)),
			ShadowtlsInnerPassword: textFromPtr(normalizeZeroString(&e.ShadowTLSInnerPassword)),
		})
		if err != nil {
			return created, fmt.Errorf("could not sync inbound %s: %w", e.Tag, err)
		}
		if err := h.store.InvalidateInbound(ctx, e.Tag, e.Protocol, oldProtocol); err != nil {
			return created, fmt.Errorf("could not invalidate inbound cache for %s: %w", e.Tag, err)
		}
		if row.Inserted {
			if err := createDefaultHost(ctx, h.store.Queries, e.Tag, e.Port); err != nil {
				return created, fmt.Errorf("could not create default host for %s: %w", e.Tag, err)
			}
			created++
		}
	}
	if err := h.store.InvalidateNodeConfigPayload(ctx); err != nil {
		h.logger.Warn("invalidate node config cache", "error", err)
	}
	return created, nil
}

// handleSyncInbounds implements POST /api/inbounds/sync (sudo only) - an
// interim stand-in for the real proxy-core-config sync the node-agent phase
// will do.
func (h *Handler) handleSyncInbounds(c *gin.Context) {
	var entries []inboundSyncEntry
	if err := c.ShouldBindJSON(&entries); err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": err.Error()})
		return
	}
	created, err := h.syncInboundEntries(c.Request.Context(), entries)
	if err != nil {
		var verr *inboundValidationError
		if errors.As(err, &verr) {
			c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": verr.msg})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"detail": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"synced": len(entries), "created": created})
}

// tlsRequiredProtocols mirrors syncInboundEntries's own check - duplicated
// as a lookup set here (rather than calling into that function just to
// learn this) so handleCreateInbound can decide whether to auto-generate a
// certificate before validation ever runs.
var tlsRequiredProtocols = map[string]bool{"hysteria2": true, "tuic": true, "anytls": true, "hysteria": true}

// handleCreateInbound implements POST /api/inbounds (sudo only): a direct,
// one-shot "add this protocol on this port" creation for the dashboard's
// own "+ Add inbound" form - unlike POST /api/inbounds/sync's array/upsert
// shape (built for bulk sync from an external source, and silently
// updating an existing tag's settings without touching its host), this
// always creates exactly one brand-new tag, rejects a tag that already
// exists instead of quietly upserting it, and gives it a real, immediately
// working host (see createDefaultHost's own doc comment on the port it's
// handed).
//
// Security="tls" with no certificate supplied gets one generated on the
// spot (certs.GenerateSelfSignedLeaf), and protocol="snell" with no PSK
// supplied gets one generated too - without this, hysteria2/tuic/anytls
// (TLS-mandatory at the sing-box level) or snell (PSK-mandatory, see
// syncInboundEntries's own check) would be created but sit inert or get
// rejected outright, which defeats the entire point of a one-click "add
// this protocol" action. A caller that brings its own certificate or PSK
// (e.g. a real certificate for a public domain) is never overridden.
func (h *Handler) handleCreateInbound(c *gin.Context) {
	var e inboundSyncEntry
	if err := c.ShouldBindJSON(&e); err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": err.Error()})
		return
	}
	if e.Port <= 0 || e.Port > 65535 {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": "port must be between 1 and 65535"})
		return
	}

	ctx := c.Request.Context()
	if _, err := h.store.Queries.GetInboundByTag(ctx, e.Tag); err == nil {
		c.JSON(http.StatusConflict, gin.H{"detail": "an inbound with tag " + e.Tag + " already exists"})
		return
	} else if !errors.Is(err, pgx.ErrNoRows) {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "could not check for an existing inbound"})
		return
	}

	if (e.Security == "tls" || tlsRequiredProtocols[e.Protocol]) && e.TLSCertificate == "" && e.TLSKey == "" {
		e.Security = "tls"
		cn := e.TLSServerName
		if cn == "" {
			cn = e.Tag
		}
		pair, err := certs.GenerateSelfSignedLeaf(cn)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"detail": "could not generate a certificate: " + err.Error()})
			return
		}
		e.TLSCertificate, e.TLSKey = pair.CertPEM, pair.KeyPEM
	}
	if e.Protocol == "snell" && e.SnellPSK == "" {
		// Reuses node.go's own secret generator (crypto/rand, 32 bytes hex) -
		// same "generate a real random credential, don't ask the admin to
		// think one up" need as a node's report secret, just for a
		// different field.
		psk, err := generateReportSecret()
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"detail": "could not generate a PSK: " + err.Error()})
			return
		}
		e.SnellPSK = psk
	}
	if e.Protocol == "shadowtls" {
		// Same one-click spirit as the snell_psk generation above: an
		// admin adding a shadowtls inbound through the dashboard's "+ Add
		// inbound" form shouldn't have to pick an AEAD method or hand-craft
		// a correctly-sized base64 key for the embedded inner layer (see
		// internal/nodecore/shadowtls's own doc comment) - defaults to the
		// AES-GCM 2022 method (hardware-accelerated on effectively every
		// modern server CPU) with a freshly generated key of exactly the
		// right length, unless the caller already supplied its own.
		if e.ShadowTLSInnerMethod == "" {
			e.ShadowTLSInnerMethod = defaultShadowTLSInnerMethod
		}
		if e.ShadowTLSInnerPassword == "" {
			keyLen, ok := shadowTLSInnerKeyLength[e.ShadowTLSInnerMethod]
			if !ok {
				c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": "invalid shadowtls_inner_method " + e.ShadowTLSInnerMethod})
				return
			}
			key, err := generateBase64Key(keyLen)
			if err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"detail": "could not generate an inner key: " + err.Error()})
				return
			}
			e.ShadowTLSInnerPassword = key
		}
	}

	if _, err := h.syncInboundEntries(ctx, []inboundSyncEntry{e}); err != nil {
		var verr *inboundValidationError
		if errors.As(err, &verr) {
			c.JSON(http.StatusUnprocessableEntity, gin.H{"detail": verr.msg})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"detail": err.Error()})
		return
	}

	row, err := h.store.Queries.GetInboundByTag(ctx, e.Tag)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"detail": "inbound created but could not be read back"})
		return
	}
	c.JSON(http.StatusOK, toInboundDetailDTO(row))
}

// inboundValidationError marks an error from syncInboundEntries as a
// client mistake (400-shaped) rather than an internal failure - same
// pattern as coreconfig.go's coreConfigValidationError, for the same
// reason: this function's callers (the plain sync handler and the
// Xray-config importer) need to tell the two apart without this function
// itself knowing about gin/HTTP status codes.
type inboundValidationError struct{ msg string }

func (e *inboundValidationError) Error() string { return e.msg }

// createDefaultHost mirrors add_default_host in the current
// crud.get_or_create_inbound: every inbound gets one default ProxyHost the
// first time it's registered. port=0 leaves it NULL (the original "no real
// port yet" behavior every existing caller relies on); a nonzero port -
// only ever passed by POST /api/inbounds's one-shot "add this protocol on
// this port" creation - writes a fully working host in the same step
// instead of leaving a second, separate Hosts-page edit required before
// this inbound actually serves anyone.
//
// Placed at the end of the existing global priority order (see migration
// 00008 and GetMaxHostPriority's own doc comment) rather than left at the
// priority column's bare default (0) - every host auto-created this way
// would otherwise land on the exact same priority, making the Hosts
// page's up/down reorder buttons a real no-op between any two of them
// (swapping two equal values changes nothing) without anything actually
// being broken in the swap logic itself.
func createDefaultHost(ctx context.Context, q *generated.Queries, tag string, port int32) error {
	maxPriority, err := q.GetMaxHostPriority(ctx)
	if err != nil {
		return fmt.Errorf("could not determine the next host priority: %w", err)
	}
	_, err = q.CreateHost(ctx, generated.CreateHostParams{
		Remark:      "Trust ({USERNAME}) [{PROTOCOL} - {TRANSPORT}]",
		Address:     "{SERVER_IP}",
		Port:        pgInt4FromZero(port),
		Security:    "inbound_default",
		Alpn:        "none",
		Fingerprint: "none",
		InboundTag:  tag,
		Priority:    maxPriority + 1,
	})
	return err
}

func realityPortToPg(port int32) pgtype.Int4 {
	if port == 0 {
		return pgtype.Int4{}
	}
	return pgtype.Int4{Int32: port, Valid: true}
}

func proxyTypeValid(protocol string) bool {
	switch protocol {
	case "vmess", "vless", "trojan", "shadowsocks", "hysteria2", "tuic", "snell", "anytls", "hysteria", "naive", "shadowtls":
		return true
	}
	return false
}

// validSnellV6Modes mirrors internal/nodecore/snell's own accepted
// snell_v6_mode values (sing-snell's snellv6.ParseMode).
var validSnellV6Modes = map[string]bool{"default": true, "unshaped": true, "unsafe-raw": true}

// defaultShadowTLSInnerMethod is handleCreateInbound's one-click default
// for a shadowtls inbound's embedded inner layer - AES-GCM over the
// ChaCha20 2022 method, since AES-NI is available on effectively every
// modern server CPU.
const defaultShadowTLSInnerMethod = "2022-blake3-aes-128-gcm"

// shadowTLSInnerKeyLength maps each shadowsocks-2022 AEAD method this
// fork's embedded inner layer accepts to its required PSK byte length
// (shadowaead_2022's own keySaltLength) - mirrors
// internal/nodecore/shadowtls's own doc comment on why that layer is
// single-key shadowsocks-2022, not the classic multi-user AEAD family
// internal/nodecore/shadowsocks already serves.
var shadowTLSInnerKeyLength = map[string]int{
	"2022-blake3-aes-128-gcm":       16,
	"2022-blake3-aes-256-gcm":       32,
	"2022-blake3-chacha20-poly1305": 32,
}

// generateBase64Key is the shadowtls_inner_password equivalent of
// generateReportSecret (node.go) - a fresh random secret, sized to
// whichever shadowsocks-2022 method it will key rather than a fixed
// length, and base64 rather than hex since that is the wire/config
// encoding every shadowsocks-2022 client and this panel's own subscription
// generation (internal/subscription) already expect.
func generateBase64Key(n int) (string, error) {
	raw := make([]byte, n)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(raw), nil
}

// pruneOrphanedProxies deletes every proxy whose protocol no longer has any
// inbound at all - see PruneOrphanedProxies's own doc comment for why this
// matters (a protocol dropped from the live config, e.g. going from
// vless+vmess+trojan down to vless-only, otherwise leaves dead vmess/trojan
// credentials sitting in every affected user's proxies forever).
//
// Deliberately refuses to run at all when there are currently zero inbounds
// of ANY protocol: PruneOrphanedProxies's `NOT IN (SELECT ... FROM
// inbounds)` would otherwise treat an empty inbounds table as "every
// protocol is orphaned" and delete every proxy for every user - a real risk
// during a legitimate "clear everything, then re-import" admin workflow
// (this migration's own Core Config reset did exactly that), not just a
// hypothetical edge case.
func (h *Handler) pruneOrphanedProxies(ctx context.Context) (int, error) {
	inbounds, err := h.store.Queries.ListInbounds(ctx)
	if err != nil {
		return 0, fmt.Errorf("could not list inbounds: %w", err)
	}
	if len(inbounds) == 0 {
		return 0, nil
	}
	removed, err := h.store.Queries.PruneOrphanedProxies(ctx)
	if err != nil {
		return 0, fmt.Errorf("could not prune orphaned proxies: %w", err)
	}
	return len(removed), nil
}
