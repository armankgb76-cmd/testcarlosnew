package main

import (
	"context"
	"reflect"
	"testing"

	"github.com/your-org/trust-vpn/internal/nodecore"
	"github.com/your-org/trust-vpn/internal/nodecore/traffic"
)

func vlessInbound(tag string, users ...userSpec) inboundSpec {
	return inboundSpec{Tag: tag, Protocol: "vless", ListenPort: 8443, Users: users}
}

func TestDiffPulledConfigFirstPullAlwaysRestarts(t *testing.T) {
	needsRestart, hot := diffPulledConfig(nil, pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1")}})
	if !needsRestart || hot != nil {
		t.Errorf("first pull: needsRestart=%v hot=%v, want true/nil", needsRestart, hot)
	}
}

func TestDiffPulledConfigIdenticalIsNoOp(t *testing.T) {
	cfg := pulledConfig{Version: "v1", Inbounds: []inboundSpec{vlessInbound("in1", userSpec{Name: "a", UUID: "u1"})}}
	needsRestart, hot := diffPulledConfig(&cfg, cfg)
	if needsRestart || len(hot) != 0 {
		t.Errorf("identical config: needsRestart=%v hot=%v, want false/empty", needsRestart, hot)
	}
}

func TestDiffPulledConfigOnlyVlessUsersChangedHotApplies(t *testing.T) {
	old := pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1", userSpec{Name: "a", UUID: "u1"})}}
	next := pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1", userSpec{Name: "a", UUID: "u1"}, userSpec{Name: "b", UUID: "u2"})}}
	needsRestart, hot := diffPulledConfig(&old, next)
	if needsRestart {
		t.Fatal("only a vless inbound's users changed - want a hot apply, not a restart")
	}
	if want := []userUpdate{{Tag: "in1", Protocol: "vless"}}; !reflect.DeepEqual(hot, want) {
		t.Errorf("hot = %v, want %v", hot, want)
	}
}

// Every protocol has a hot-update path now, so a change that is only an
// inbound's user list must never restart the core - and must name the protocol
// so pullOnce calls the right update.
func TestDiffPulledConfigOnlyUsersChangedHotAppliesForEveryProtocol(t *testing.T) {
	cases := []struct {
		protocol string
		before   []userSpec
		after    []userSpec
	}{
		{"vless", []userSpec{{Name: "a", UUID: "u1"}}, []userSpec{{Name: "a", UUID: "u1"}, {Name: "b", UUID: "u2"}}},
		{"vmess", []userSpec{{Name: "a", UUID: "u1"}}, []userSpec{{Name: "a", UUID: "u9"}}},
		{"trojan", []userSpec{{Name: "a", Password: "p1"}}, []userSpec{{Name: "a", Password: "p2"}}},
		{"trojan", []userSpec{{Name: "a", Password: "p1"}}, nil},
		{"shadowsocks", []userSpec{{Name: "a", Password: "p1", Method: "aes-256-gcm"}}, []userSpec{{Name: "a", Password: "p1", Method: "aes-256-gcm"}, {Name: "b", Password: "p2", Method: "aes-256-gcm"}}},
		{"shadowsocks", nil, []userSpec{{Name: "a", Password: "p1"}}},
	}
	for _, c := range cases {
		old := pulledConfig{Inbounds: []inboundSpec{{Tag: "in1", Protocol: c.protocol, ListenPort: 443, Users: c.before}}}
		next := pulledConfig{Inbounds: []inboundSpec{{Tag: "in1", Protocol: c.protocol, ListenPort: 443, Users: c.after}}}
		needsRestart, hot := diffPulledConfig(&old, next)
		if needsRestart {
			t.Errorf("%s: only the user list changed - want a hot apply, not a restart", c.protocol)
			continue
		}
		if want := []userUpdate{{Tag: "in1", Protocol: c.protocol}}; !reflect.DeepEqual(hot, want) {
			t.Errorf("%s: hot = %v, want %v", c.protocol, hot, want)
		}
	}
}

func TestDiffPulledConfigHotListNamesEachChangedInboundWithItsOwnProtocol(t *testing.T) {
	inbounds := func(trojanPass, vmessID string) []inboundSpec {
		return []inboundSpec{
			vlessInbound("untouched", userSpec{Name: "a", UUID: "u1"}),
			{Tag: "t", Protocol: "trojan", ListenPort: 443, Users: []userSpec{{Name: "a", Password: trojanPass}}},
			{Tag: "m", Protocol: "vmess", ListenPort: 444, Users: []userSpec{{Name: "a", UUID: vmessID}}},
		}
	}
	needsRestart, hot := diffPulledConfig(&pulledConfig{Inbounds: inbounds("p1", "v1")}, pulledConfig{Inbounds: inbounds("p2", "v2")})
	if needsRestart {
		t.Fatal("only user lists changed - want a hot apply")
	}
	if want := []userUpdate{{Tag: "t", Protocol: "trojan"}, {Tag: "m", Protocol: "vmess"}}; !reflect.DeepEqual(hot, want) {
		t.Errorf("hot = %v, want %v", hot, want)
	}
}

func TestDiffPulledConfigUserChangeOnAnUnknownProtocolNeedsRestart(t *testing.T) {
	old := pulledConfig{Inbounds: []inboundSpec{{Tag: "in1", Protocol: "not-a-real-protocol", ListenPort: 443, Users: []userSpec{{Name: "a", Password: "p1"}}}}}
	next := pulledConfig{Inbounds: []inboundSpec{{Tag: "in1", Protocol: "not-a-real-protocol", ListenPort: 443, Users: []userSpec{{Name: "a", Password: "p2"}}}}}
	if needsRestart, _ := diffPulledConfig(&old, next); !needsRestart {
		t.Error("a protocol with no hot-update path changed its users - want a restart")
	}
}

// The cipher rides on the users in the wire contract but belongs to the
// listener: a hot update would accept the new users and silently keep the old
// cipher, so a change of it has to restart.
func TestDiffPulledConfigShadowsocksCipherChangeNeedsRestart(t *testing.T) {
	ss := func(method string) pulledConfig {
		return pulledConfig{Inbounds: []inboundSpec{{Tag: "in1", Protocol: "shadowsocks", ListenPort: 8388, Users: []userSpec{{Name: "a", Password: "p1", Method: method}}}}}
	}
	old, next := ss("aes-128-gcm"), ss("aes-256-gcm")
	if needsRestart, _ := diffPulledConfig(&old, next); !needsRestart {
		t.Error("the shadowsocks cipher changed - want a restart, a running listener cannot swap it")
	}
	// Spelling out the default is not a change.
	old, next = ss(""), ss(defaultShadowsocksMethod)
	if needsRestart, hot := diffPulledConfig(&old, next); needsRestart || len(hot) != 1 {
		t.Errorf("default cipher spelled out: needsRestart=%v hot=%v, want a hot apply", needsRestart, hot)
	}
}

func TestDiffPulledConfigInboundShapeChangedNeedsRestart(t *testing.T) {
	old := pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1")}}
	next := pulledConfig{Inbounds: []inboundSpec{{Tag: "in1", Protocol: "vless", ListenPort: 9443}}} // port changed
	needsRestart, _ := diffPulledConfig(&old, next)
	if !needsRestart {
		t.Error("listen port changed - want a restart, hot-apply can't rebind a listener")
	}
}

func TestDiffPulledConfigInboundAddedOrRemovedNeedsRestart(t *testing.T) {
	old := pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1")}}
	next := pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1"), vlessInbound("in2")}}
	if needsRestart, _ := diffPulledConfig(&old, next); !needsRestart {
		t.Error("a new inbound appeared - want a restart")
	}
	if needsRestart, _ := diffPulledConfig(&next, old); !needsRestart {
		t.Error("an inbound disappeared - want a restart")
	}
}

func TestDiffPulledConfigCoreChangeNeedsRestart(t *testing.T) {
	old := pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1")}, Core: coreSpec{LogLevel: "warn"}}
	next := pulledConfig{Inbounds: []inboundSpec{vlessInbound("in1")}, Core: coreSpec{LogLevel: "debug"}}
	if needsRestart, _ := diffPulledConfig(&old, next); !needsRestart {
		t.Error("core config changed (log level) - want a restart even though no inbound changed at all")
	}
}

// TestBuildOptionsWithFullCoreIsAcceptedBySingBox is the real proof that
// buildCoreOptions's hand-built sing-box option structs are actually
// valid, not just "compiles" - it builds a realistic Core Config (a
// custom outbound, a routing rule targeting it, a DNS server, sniffing
// enabled) end to end through nodecore.New/Start, the exact same path a
// real node process uses, and asserts sing-box's own real startup
// validation accepts it without error.
func TestBuildOptionsWithFullCoreIsAcceptedBySingBox(t *testing.T) {
	req := startRequest{
		Inbounds: []inboundSpec{{Tag: "vless-in", Protocol: "vless", ListenPort: 0, Users: []userSpec{{Name: "u", UUID: "8f8a4c1e-1e2a-4b8a-9b1a-000000000099"}}}},
		Core: &coreSpec{
			LogLevel:     "warn",
			SniffEnabled: true,
			Outbounds: []outboundSpec{
				{Tag: "upstream", Type: "socks", Server: "127.0.0.1", ServerPort: 1080},
			},
			RoutingRules: []routingRuleSpec{
				{IPIsPrivate: true, OutboundTag: "block"},
				{DomainSuffix: []string{"example.com"}, OutboundTag: "upstream"},
			},
			DNSServers: []dnsServerSpec{
				{Tag: "dns1", Type: "udp", Address: "1.1.1.1"},
			},
		},
	}
	opts, err := buildOptions(req)
	if err != nil {
		t.Fatalf("buildOptions: %v", err)
	}
	if len(opts.Outbounds) != 3 { // direct-out, block-out, upstream
		t.Fatalf("len(Outbounds) = %d, want 3 (implicit direct+block, plus the custom one)", len(opts.Outbounds))
	}
	if opts.Route == nil || len(opts.Route.Rules) != 3 { // sniff-all + 2 routing rules
		t.Fatalf("Route.Rules = %v, want 3 (sniff + 2 custom rules)", opts.Route)
	}
	if opts.DNS == nil || len(opts.DNS.Servers) != 1 {
		t.Fatalf("DNS.Servers = %v, want 1", opts.DNS)
	}

	node, err := nodecore.New(context.Background(), opts, traffic.NewManager())
	if err != nil {
		t.Fatalf("nodecore.New rejected the built options: %v", err)
	}
	if err := node.Start(); err != nil {
		t.Fatalf("sing-box rejected the built options at Start: %v", err)
	}
	t.Cleanup(func() { node.Close() })
}

// testCertPEM/testKeyPEM mirror internal/httpapi/harness_test.go's own
// fixture of the same name (a real, valid, self-signed ECDSA cert/key pair,
// CN=example.test) - duplicated rather than imported since cmd/node is a
// separate package/module boundary from internal/httpapi.
const testCertPEM = `-----BEGIN CERTIFICATE-----
MIIBXTCCAQOgAwIBAgIBATAKBggqhkjOPQQDAjAXMRUwEwYDVQQDEwxleGFtcGxl
LnRlc3QwHhcNMjYwOTA3MTI1MjM4WhcNMzYwOTA3MTM1MjM4WjAXMRUwEwYDVQQD
EwxleGFtcGxlLnRlc3QwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAATyGO/P9eCr
vTXXCTRjgfAF7ndDAU1SM+DTYBOj6rVaa9+tRvJ6l3vYpZtT2D2NMPBMzgVuV8iG
u8A9/JcE/irMo0AwPjAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUH
AwEwFwYDVR0RBBAwDoIMZXhhbXBsZS50ZXN0MAoGCCqGSM49BAMCA0gAMEUCIQDq
gibaZwip7+t66D64WsXJ9SBOsKTq+L3t5Thc5bzaFQIgOC73EDy+FbfuttkW+X8N
hbY2Lo7pOEX6xRezdduatlo=
-----END CERTIFICATE-----
`

const testKeyPEM = `-----BEGIN EC PRIVATE KEY-----
MHcCAQEEICiESJZ2LnzP+hpr9U26Puzb5DoiaYNIH/vBsj4wAoDvoAoGCCqGSM49
AwEHoUQDQgAE8hjvz/Xgq7011wk0Y4HwBe53QwFNUjPg02ATo+q1WmvfrUbyepd7
2KWbU9g9jTDwTM4FblfIhrvAPfyXBP4qzA==
-----END EC PRIVATE KEY-----
`

// TestBuildOptionsWithRealTLSInboundRoutingRuleAndBindInterfaceIsAccepted
// is the real proof for the three gaps this session's work closes (see
// the plan: TLS certificate storage, inbound-tag routing, outbound
// bind_interface) - a real self-signed cert/key pair on a vless inbound, a
// routing rule matching that same inbound tag, and a direct outbound bound
// to a real local interface name, all run through the exact
// nodecore.New/Start path a real node process uses. bind_interface is set
// to "lo" (loopback) rather than a fabricated name specifically so this
// proves sing-box accepts a *real* interface, not just that the field
// round-trips syntactically - a nonexistent interface name is a separate,
// deliberately-not-covered runtime failure (see the plan's own note that
// full multi-WireGuard-interface routing can't be proven on a single-NIC
// test box).
func TestBuildOptionsWithRealTLSInboundRoutingRuleAndBindInterfaceIsAccepted(t *testing.T) {
	req := startRequest{
		Inbounds: []inboundSpec{{
			Tag: "tls-in", Protocol: "vless", ListenPort: 0,
			Users: []userSpec{{Name: "u", UUID: "8f8a4c1e-1e2a-4b8a-9b1a-000000000098"}},
			TLS:   &tlsSpec{ServerName: "example.test", Certificate: testCertPEM, Key: testKeyPEM},
		}},
		Core: &coreSpec{
			LogLevel: "warn",
			Outbounds: []outboundSpec{
				{Tag: "bound-out", Type: "direct", BindInterface: "lo"},
			},
			RoutingRules: []routingRuleSpec{
				{Inbound: []string{"tls-in"}, OutboundTag: "bound-out"},
			},
		},
	}
	opts, err := buildOptions(req)
	if err != nil {
		t.Fatalf("buildOptions: %v", err)
	}
	if len(opts.Route.Rules) != 1 {
		t.Fatalf("Route.Rules = %v, want 1", opts.Route.Rules)
	}

	node, err := nodecore.New(context.Background(), opts, traffic.NewManager())
	if err != nil {
		t.Fatalf("nodecore.New rejected the built options: %v", err)
	}
	if err := node.Start(); err != nil {
		t.Fatalf("sing-box rejected a real TLS cert + inbound-tag routing rule + bind_interface config at Start: %v", err)
	}
	t.Cleanup(func() { node.Close() })
}

// TestEachOutboundProtocolIsAcceptedBySingBox is the real proof that every
// outbound type Core Config's structured form offers (see
// internal/httpapi/coreconfig.go's validOutboundTypes) actually has a
// working translation in buildCoreOptions and a real registration in
// internal/nodecore/registry.go's OutboundRegistry - each one is run
// through the exact same nodecore.New/Start path a real node process
// uses, not just asserted to compile. This is the table-driven form of
// TestBuildOptionsWithFullCoreIsAcceptedBySingBox, isolating exactly
// which protocol fails if one does (this is how the DNS transport
// registry gap and, later, the missing hysteria2/tuic go.sum entries were
// both first caught).
func TestEachOutboundProtocolIsAcceptedBySingBox(t *testing.T) {
	cases := []struct {
		name     string
		outbound outboundSpec
	}{
		{"direct", outboundSpec{Tag: "ob", Type: "direct"}},
		{"block", outboundSpec{Tag: "ob", Type: "block"}},
		{"socks", outboundSpec{Tag: "ob", Type: "socks", Server: "203.0.113.1", ServerPort: 1080}},
		{"http", outboundSpec{Tag: "ob", Type: "http", Server: "203.0.113.1", ServerPort: 8080}},
		{"shadowsocks", outboundSpec{Tag: "ob", Type: "shadowsocks", Server: "203.0.113.1", ServerPort: 8388, Method: "aes-256-gcm", Password: "test-passphrase"}},
		{"vmess", outboundSpec{Tag: "ob", Type: "vmess", Server: "203.0.113.1", ServerPort: 443, UUID: "8f8a4c1e-1e2a-4b8a-9b1a-0000000000aa", Security: "auto"}},
		{"vmess-tls", outboundSpec{Tag: "ob", Type: "vmess", Server: "example.com", ServerPort: 443, UUID: "8f8a4c1e-1e2a-4b8a-9b1a-0000000000ab", Security: "auto", TLSEnabled: true, TLSServerName: "example.com"}},
		{"trojan", outboundSpec{Tag: "ob", Type: "trojan", Server: "example.com", ServerPort: 443, Password: "trojan-pass", TLSEnabled: true, TLSServerName: "example.com"}},
		{"vless", outboundSpec{Tag: "ob", Type: "vless", Server: "203.0.113.1", ServerPort: 443, UUID: "8f8a4c1e-1e2a-4b8a-9b1a-0000000000ac"}},
		{"hysteria2", outboundSpec{Tag: "ob", Type: "hysteria2", Server: "example.com", ServerPort: 443, Password: "h2-pass"}},
		{"tuic", outboundSpec{Tag: "ob", Type: "tuic", Server: "example.com", ServerPort: 443, UUID: "8f8a4c1e-1e2a-4b8a-9b1a-0000000000ad", Password: "tuic-pass", CongestionControl: "bbr"}},
		{"selector", outboundSpec{Tag: "ob", Type: "selector", Outbounds: []string{"direct"}}},
		{"urltest", outboundSpec{Tag: "ob", Type: "urltest", Outbounds: []string{"direct"}}},
		{"anytls", outboundSpec{Tag: "ob", Type: "anytls", Server: "example.com", ServerPort: 443, Password: "anytls-pass"}},
		{"hysteria", outboundSpec{Tag: "ob", Type: "hysteria", Server: "example.com", ServerPort: 443, Password: "hy-auth", Obfs: "hy-obfs", UpMbps: 50, DownMbps: 200}},
		{"shadowtls", outboundSpec{Tag: "ob", Type: "shadowtls", Server: "example.com", ServerPort: 443, Version: 3, Password: "stls-pass"}},
		{"shadowtls-v1", outboundSpec{Tag: "ob", Type: "shadowtls", Server: "example.com", ServerPort: 443, Version: 1}},
		{"snell", outboundSpec{Tag: "ob", Type: "snell", Server: "203.0.113.1", ServerPort: 2000, PSK: "snell-psk"}},
		{"snell-obfs", outboundSpec{Tag: "ob", Type: "snell", Server: "203.0.113.1", ServerPort: 2000, PSK: "snell-psk", ObfsMode: "http", ObfsHost: "example.com"}},
		{"ssh", outboundSpec{Tag: "ob", Type: "ssh", Server: "203.0.113.1", ServerPort: 22, Username: "sshuser", Password: "sshpass"}},
		// "tor" is deliberately absent from this table: unlike every other
		// outbound here, its Start actually spawns a local `tor` process
		// (see TestTorOutboundConstructsAndRegistersWithoutSpawningTor for
		// what this test suite can safely prove about it instead).
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			opts, err := buildOptions(startRequest{Core: &coreSpec{Outbounds: []outboundSpec{tc.outbound}}})
			if err != nil {
				t.Fatalf("buildOptions: %v", err)
			}
			node, err := nodecore.New(context.Background(), opts, traffic.NewManager())
			if err != nil {
				t.Fatalf("nodecore.New: %v", err)
			}
			if err := node.Start(); err != nil {
				t.Fatalf("sing-box rejected a %s outbound: %v", tc.name, err)
			}
			node.Close()
		})
	}
}

// TestTorOutboundConstructsAndRegistersWithoutSpawningTor is the tor
// counterpart to TestEachOutboundProtocolIsAcceptedBySingBox, proving the
// registration in internal/nodecore/registry.go and the translation in
// leafOutboundOptions both work, without calling Node.Start - unlike every
// other outbound type, a tor outbound's Start actually spawns a local `tor`
// process (see sing-box's protocol/tor.Outbound.Start), which no dev machine
// or CI runner here has installed. nodecore.New (box.New) only constructs
// the outbound; per its own doc comment, sing-box's pre-start pass - the
// step that would try to launch tor - runs inside Start, not New.
func TestTorOutboundConstructsAndRegistersWithoutSpawningTor(t *testing.T) {
	opts, err := buildOptions(startRequest{Core: &coreSpec{Outbounds: []outboundSpec{{Tag: "ob", Type: "tor"}}}})
	if err != nil {
		t.Fatalf("buildOptions: %v", err)
	}
	node, err := nodecore.New(context.Background(), opts, traffic.NewManager())
	if err != nil {
		t.Fatalf("nodecore.New: %v", err)
	}
	node.Close() // safe before Start; see tor.Outbound.Close's own nil guards
}

func TestEachDNSServerTypeIsAcceptedBySingBox(t *testing.T) {
	cases := []struct {
		name string
		srv  dnsServerSpec
	}{
		{"local", dnsServerSpec{Tag: "d", Type: "local"}},
		{"udp", dnsServerSpec{Tag: "d", Type: "udp", Address: "1.1.1.1"}},
		{"tcp", dnsServerSpec{Tag: "d", Type: "tcp", Address: "1.1.1.1"}},
		{"tls", dnsServerSpec{Tag: "d", Type: "tls", Address: "1.1.1.1"}},
		{"https", dnsServerSpec{Tag: "d", Type: "https", Address: "1.1.1.1", Path: "/dns-query"}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			opts, err := buildOptions(startRequest{Core: &coreSpec{DNSServers: []dnsServerSpec{tc.srv}}})
			if err != nil {
				t.Fatalf("buildOptions: %v", err)
			}
			node, err := nodecore.New(context.Background(), opts, traffic.NewManager())
			if err != nil {
				t.Fatalf("nodecore.New: %v", err)
			}
			if err := node.Start(); err != nil {
				t.Fatalf("sing-box rejected a %s dns server: %v", tc.name, err)
			}
			node.Close()
		})
	}
}

func TestBuildOptionsRejectsUnknownOutboundType(t *testing.T) {
	req := startRequest{Core: &coreSpec{Outbounds: []outboundSpec{{Tag: "x", Type: "not-a-real-type"}}}}
	if _, err := buildOptions(req); err == nil {
		t.Error("buildOptions accepted an unknown outbound type, want an error")
	}
}

func TestBuildOptionsNilCoreMatchesOriginalHardcodedBehavior(t *testing.T) {
	opts, err := buildOptions(startRequest{Inbounds: []inboundSpec{vlessInbound("in1")}})
	if err != nil {
		t.Fatalf("buildOptions: %v", err)
	}
	if len(opts.Outbounds) != 2 {
		t.Errorf("len(Outbounds) = %d, want 2 (just the implicit direct+block, no Core supplied)", len(opts.Outbounds))
	}
	if opts.Route == nil || opts.Route.Final != implicitOutboundTagDirect {
		t.Errorf("Route.Final = %v, want %q", opts.Route, implicitOutboundTagDirect)
	}
}
