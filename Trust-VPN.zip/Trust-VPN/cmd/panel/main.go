// Command panel is the trust-vpn entrypoint. It runs in one of two roles,
// set via the ROLE env var - "api" (stateless, horizontally replicated) or
// "backend" (the singleton owning node connections, core lifecycle and
// schedulers) - mirroring the current Python panel's process model. Phase 0
// and 1 only implement the api role's HTTP surface; the backend role's
// node/core responsibilities land in later phases.
package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"strconv"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/your-org/trust-vpn/internal/auth"
	"github.com/your-org/trust-vpn/internal/cache"
	"github.com/your-org/trust-vpn/internal/certs"
	"github.com/your-org/trust-vpn/internal/config"
	"github.com/your-org/trust-vpn/internal/db/generated"
	"github.com/your-org/trust-vpn/internal/discord"
	"github.com/your-org/trust-vpn/internal/gatewayjob"
	"github.com/your-org/trust-vpn/internal/hostmetrics"
	"github.com/your-org/trust-vpn/internal/httpapi"
	"github.com/your-org/trust-vpn/internal/integrationsettings"
	"github.com/your-org/trust-vpn/internal/logstream"
	"github.com/your-org/trust-vpn/internal/relayhealth"
	"github.com/your-org/trust-vpn/internal/report"
	"github.com/your-org/trust-vpn/internal/resellerapi"
	"github.com/your-org/trust-vpn/internal/resellerusagejob"
	"github.com/your-org/trust-vpn/internal/reviewjob"
	"github.com/your-org/trust-vpn/internal/telegram"
	"github.com/your-org/trust-vpn/internal/telegrambot"
	"github.com/your-org/trust-vpn/internal/tunnelmetrics"
	"github.com/your-org/trust-vpn/internal/usagejob"
)

func main() {
	// Same JSON lines on stdout as a plain JSON handler; each one is also kept
	// in the process' log ring, which run() starts publishing to Redis once it
	// knows the role (see internal/logstream).
	logger := slog.New(logstream.NewHandler(os.Stdout, nil, logstream.ProcessRing()))

	if err := run(logger); err != nil {
		logger.Error("fatal", "error", err)
		os.Exit(1)
	}
}

// version is stamped at build time (-ldflags "-X main.version=..." in
// docker/Dockerfile.panel); "dev" means a plain `go build`.
var version = "dev"

func run(logger *slog.Logger) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	logger.Info("starting", "role", cfg.Role, "version", version)

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	poolCfg, err := pgxpool.ParseConfig(cfg.DatabaseURL)
	if err != nil {
		return err
	}
	poolCfg.MaxConns = dbPoolMaxConns(cfg.Role)
	pool, err := pgxpool.NewWithConfig(ctx, poolCfg)
	if err != nil {
		return err
	}
	defer pool.Close()
	if err := pool.Ping(ctx); err != nil {
		return err
	}
	logger.Info("connected to postgres")

	redisClient := cache.New(cfg.RedisAddr, cfg.RedisPass, cfg.RedisDB, logger)
	defer redisClient.Close()
	if err := redisClient.Ping(ctx); err != nil {
		return err
	}
	logger.Info("connected to redis")

	// Mirror this process' log ring into Redis so the dashboard can read it
	// from whichever panel process serves the request.
	logSource := "panel"
	if cfg.Role == config.RoleBackend {
		logSource = "backend"
	}
	logstream.SetProcessSource(logSource)
	go logstream.NewPublisher(redisClient.Raw(), logSource, logstream.ProcessRing(), logger).Run(ctx)

	queries := generated.New(pool)

	secret, err := ensureJWTSecret(ctx, queries)
	if err != nil {
		return err
	}
	issuer := auth.NewTokenIssuer(secret, cfg.JWTAccessTTL)

	if err := ensureTLS(ctx, queries, logger); err != nil {
		return err
	}

	store := httpapi.NewStore(pool, redisClient)

	envDefaults := integrationsettings.Values{
		ResellerApiSecret: cfg.ResellerApiSecret, ResellerApiUrl: cfg.ResellerApiUrl, ResellerApiLicense: cfg.ResellerApiLicense,
		TelegramAPIToken: cfg.TelegramAPIToken, TelegramAdminIDs: cfg.TelegramAdminIDs, TelegramProxyURL: cfg.TelegramProxyURL,
		TelegramLoggerChannelID: cfg.TelegramLoggerChannelID, TelegramLoggerTopicID: cfg.TelegramLoggerTopicID,
		TelegramDefaultVlessFlow: cfg.TelegramDefaultVlessFlow,
		WebhookAddresses:         cfg.WebhookAddresses, WebhookSecret: cfg.WebhookSecret, DiscordWebhookURL: cfg.DiscordWebhookURL,
	}
	settingsFn := func(ctx context.Context) (integrationsettings.Values, error) {
		row, err := store.CachedGetIntegrationSettings(ctx)
		if err != nil {
			return integrationsettings.Values{}, err
		}
		return integrationsettings.Resolve(row, envDefaults), nil
	}
	notifyHTTPClient := &http.Client{Timeout: 10 * time.Second}
	dispatcher := report.New(report.NotifyFlags{
		StatusChange: cfg.NotifyStatusChange, UserCreated: cfg.NotifyUserCreated, UserUpdated: cfg.NotifyUserUpdated,
		UserDeleted: cfg.NotifyUserDeleted, UserDataUsedReset: cfg.NotifyUserDataUsedReset,
		UserSubRevoked: cfg.NotifyUserSubRevoked, Login: cfg.NotifyLogin, InfraAlert: cfg.NotifyInfraAlert,
	}, settingsFn, telegram.NewSender(notifyHTTPClient, ""), discord.NewSender(notifyHTTPClient), logger)
	resellerAPIClient := resellerapi.NewClient(&http.Client{Timeout: 3 * time.Second})
	hostMetricsTracker := hostmetrics.NewPreviousTracker()

	// The Telegram admin console runs only in the backend singleton; it is
	// handed the router below once that exists (SetAPI).
	var telegramConsole *telegrambot.Console
	if cfg.Role == config.RoleBackend {
		// Its own client: see internal/resellerusagejob for why a usage
		// report must not share the 3s timeout of the per-request lookups.
		usageReporter := resellerapi.NewClient(&http.Client{Timeout: 30 * time.Second})
		telegramConsole = telegrambot.New(telegrambot.Deps{
			Queries: queries, Cache: redisClient, Issuer: issuer, SudoUsername: cfg.SudoUsername,
			Settings: settingsFn, Logger: logger,
		})
		go runAsBackendSingleton(ctx, cfg.DatabaseURL, queries, dispatcher, hostMetricsTracker, redisClient, usageReporter, settingsFn, cfg.UsageRetentionDays, telegramConsole.Run, logger)
	}

	formatFlags := httpapi.SubscriptionFormatFlags{
		Default: cfg.UseCustomJSONDefault, V2RayN: cfg.UseCustomJSONForV2RayN, V2RayNG: cfg.UseCustomJSONForV2RayNG,
		Streisand: cfg.UseCustomJSONForStreisand, Happ: cfg.UseCustomJSONForHapp, NPVTunnel: cfg.UseCustomJSONForNPVTunnel,
	}
	subBranding := httpapi.SubscriptionBranding{
		SupportURL: cfg.SubSupportURL, ProfileTitle: cfg.SubProfileTitle, UpdateInterval: cfg.SubUpdateInterval,
	}
	handler := httpapi.NewHandler(store, issuer, cfg.SudoUsername, cfg.SudoPassword, secret, cfg.PublicIP, cfg.SubscriptionURLPrefix,
		cfg.ClashTemplateFile, cfg.V2raySubscriptionTemplateFile, formatFlags, subBranding,
		envDefaults, dispatcher, resellerAPIClient, cfg.LoginNotifyWhitelist, hostMetricsTracker,
		cfg.DatabaseURL, cfg.BackupDir, cfg.BackupKeep, logger).WithSubscriptionURLPrefixes(cfg.SubscriptionURLPrefixes).WithNodeBinDir(cfg.NodeBinDir).
		WithConfigLoad(cfg.ConfigLoadIndicator, cfg.ConfigLoadCapacity, cfg.ConfigSortByLoad)
	router := httpapi.NewRouter(handler, logger, cfg.AllowedOrigins)
	httpapi.MountDashboardStatic(router, cfg.DashboardDir)
	if telegramConsole != nil {
		telegramConsole.SetAPI(router)
	}

	srv := &http.Server{
		Addr:              cfg.HTTPHost + ":" + strconv.Itoa(cfg.HTTPPort),
		Handler:           router,
		ReadHeaderTimeout: 10 * time.Second,
	}

	go func() {
		<-ctx.Done()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		logger.Info("shutting down")
		if err := srv.Shutdown(shutdownCtx); err != nil {
			logger.Error("shutdown error", "error", err)
		}
	}()

	logger.Info("listening", "addr", srv.Addr)
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		return err
	}
	return nil
}

// runAsBackendSingleton holds a session-scoped Postgres advisory lock for
// as long as this process is the active backend singleton - the direct
// Postgres equivalent of the current system's MySQL GET_LOCK() usage,
// which exists because a duplicate BACKEND role process double-driving the
// same background jobs (and, in later phases, the same node connections)
// caused a real production outage once. Retries on an interval if another
// backend process already holds the lock, so a second instance started by
// mistake (or during a rolling restart) waits rather than running
// alongside the first one.
//
// Uses a single dedicated connection opened directly with pgx, not one
// borrowed from the pgxpool: a session-level advisory lock lives exactly
// as long as its holding connection does, and a pool connection can be
// silently recycled or closed at any time, which would release the lock
// out from under this process without it noticing.
func runAsBackendSingleton(ctx context.Context, databaseURL string, queries *generated.Queries, dispatcher *report.Dispatcher, hostMetricsTracker *hostmetrics.PreviousTracker, redisClient *cache.Client, usageReporter *resellerapi.Client, settingsFn resellerusagejob.SettingsFunc, usageRetentionDays int, runConsole func(context.Context), logger *slog.Logger) {
	const retryInterval = 10 * time.Second
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		conn, err := pgx.Connect(ctx, databaseURL)
		if err != nil {
			logger.Error("backend singleton: connect for advisory lock", "error", err)
			time.Sleep(retryInterval)
			continue
		}

		var acquired bool
		if err := conn.QueryRow(ctx, "SELECT pg_try_advisory_lock($1)", cache.AdvisoryLockBackendSingleton).Scan(&acquired); err != nil {
			logger.Error("backend singleton: pg_try_advisory_lock", "error", err)
			conn.Close(ctx)
			time.Sleep(retryInterval)
			continue
		}
		if !acquired {
			logger.Info("backend singleton: lock held elsewhere, waiting", "retry_in", retryInterval)
			conn.Close(ctx)
			time.Sleep(retryInterval)
			continue
		}

		logger.Info("backend singleton: acquired advisory lock, running background jobs")
		// Both run only here, not on every stateless API replica - a node's
		// push report and the panel's own self-sample must each be observed
		// by exactly one PreviousTracker for their rate/percent math to be
		// correct (see hostmetrics.PreviousTracker's doc comment), and
		// pruning old rows from every replica at once would just be
		// redundant DELETEs racing each other.
		go hostmetrics.PruneLoop(ctx, queries, redisClient, logger, time.Hour)
		// Drops presence entries nobody has refreshed for 6 h; one trimmer is
		// enough, so it lives here rather than on every replica.
		go httpapi.RunPresenceTrim(ctx, redisClient, logger, time.Minute)
		go hostmetrics.PanelSelfSampleLoop(ctx, queries, hostMetricsTracker, redisClient, logger, 30*time.Second)
		// Alerts on a WireGuard tunnel's up<->down transition - the data was
		// already being collected (see monitoring.go), nobody was being told.
		go hostmetrics.RunTunnelAlerts(ctx, queries, func(ctx context.Context, nodeName, tunnelName string, up bool, domain string, downFor time.Duration) {
			dispatcher.InfraAlert(ctx, "WireGuard tunnel", nodeName+"/"+tunnelName, "", up, domain, downFor)
		}, logger, 30*time.Second)
		// Probes every registered external relay (a GRE+FRP box or similar in
		// front of a node, living entirely outside this fleet - see
		// internal/relayhealth's doc comment) and alerts the same way.
		go relayhealth.New(relayhealth.Options{
			Lister: func(ctx context.Context) ([]relayhealth.Relay, error) {
				rows, err := queries.ListTunnelRelays(ctx)
				if err != nil {
					return nil, err
				}
				out := make([]relayhealth.Relay, len(rows))
				for i, r := range rows {
					out[i] = relayhealth.Relay{ID: r.ID, Name: r.Name, Host: r.Host, Port: r.Port}
				}
				return out, nil
			},
			Alert: func(ctx context.Context, r relayhealth.Relay, up bool, detail string, downFor time.Duration) {
				dispatcher.InfraAlert(ctx, "Relay", fmt.Sprintf("%s (%s:%d)", r.Name, r.Host, r.Port), detail, up, "", downFor)
			},
			// Publishes the full live snapshot every round (not just on a
			// transition, unlike Alert) so the api role's GET /api/tunnels
			// - a separate process with no Monitor of its own - can show
			// current status on the dashboard.
			OnTick: func(statuses []relayhealth.Status) {
				if err := relayhealth.PublishStatuses(ctx, redisClient, statuses); err != nil {
					logger.Warn("relayhealth: could not publish status to redis", "error", err)
				}
			},
			Logger: logger,
		}).Run(ctx)
		// CPU/RAM/disk/traffic per tunnel's relay, same page now shows this
		// alongside relayhealth's up/down - only active tunnels have both a
		// live GRE interface to read counters from and credentials worth
		// re-dialing with every round.
		go tunnelmetrics.Run(ctx, redisClient, tunnelmetrics.Options{
			Lister: func(ctx context.Context) ([]tunnelmetrics.Target, error) {
				rows, err := queries.ListTunnels(ctx)
				if err != nil {
					return nil, err
				}
				targets := make([]tunnelmetrics.Target, 0, len(rows))
				for _, t := range rows {
					if t.Status != "active" {
						continue
					}
					targets = append(targets, tunnelmetrics.Target{
						TunnelID: t.ID, RelayHost: t.RelayHost, RelaySSHPort: t.RelaySshPort,
						RelaySSHUser: t.RelaySshUser, RelaySSHPassword: t.RelaySshPassword,
						InterfaceName: t.InterfaceName, Ports: t.Ports,
					})
				}
				return targets, nil
			},
			Logger: logger,
		})
		// Gateway (multi-panel load balancer) sub-phase 4: keeps every
		// enabled peer's crowdedness/host cache warm so a real client's
		// subscription fetch never waits on a network call to another
		// panel - see internal/gatewayjob's own doc comment.
		go gatewayjob.Run(ctx, queries, redisClient, logger, 2*time.Minute)
		// Bills resellers through the reseller bot. Singleton-only so the
		// same queued traffic is never sent by two processes at once.
		go resellerusagejob.Run(ctx, queries, usageReporter, settingsFn, redisClient, logger, 10*time.Second)
		// Prunes node_user_usages hourly (USAGE_RETENTION_DAYS, 0 = keep all).
		go usagejob.Run(ctx, queries, redisClient, usageRetentionDays, logger, time.Hour)
		// Long polling: two pollers on one bot token fight, so it lives here.
		// Dormant until a Telegram bot token is configured.
		go runConsole(ctx)
		reviewjob.Run(ctx, queries, dispatcher, redisClient, logger, 10*time.Second)

		// reviewjob.Run only returns once ctx is canceled (process shutdown) -
		// release the lock and let the deferred loop exit via ctx.Done() above.
		conn.Exec(context.Background(), "SELECT pg_advisory_unlock($1)", cache.AdvisoryLockBackendSingleton)
		conn.Close(context.Background())
		return
	}
}

// dbPoolMaxConns picks the pgxpool ceiling per role. Left unset, pgxpool
// defaults to runtime.NumCPU() - fine for the backend role's handful of
// sequential background jobs, but on the api role that number becomes the
// pool itself, and the pool becomes the hard throughput ceiling: live
// benchmarking the production panel (a 10-core box, otherwise ~40% idle
// across panel+Postgres+Caddy under load) showed requests queueing for a
// pool slot at a flat ~1100 req/s regardless of client concurrency, with
// Postgres sitting on only ~9 active connections out of its max_connections
// budget the whole time. Scaling with core count keeps this sized to the
// machine instead of a fixed guess; the backend role never fans out
// concurrent DB work the way an HTTP request pool does, so it stays small
// regardless of how many cores the box has.
func dbPoolMaxConns(role config.Role) int32 {
	if role == config.RoleBackend {
		return 10
	}
	n := int32(runtime.NumCPU() * 5)
	switch {
	case n < 20:
		return 20
	case n > 50:
		return 50
	default:
		return n
	}
}

// ensureJWTSecret returns the singleton jwt_secrets row's key, generating
// and persisting one on first boot - equivalent to app/utils/jwt.py's
// get_secret_key, which lazily creates the "jwt" table's one row the same
// way via the SQLAlchemy column default.
//
// The stored column is hex - hex.DecodeString recovers the original random
// bytes. A real bug here (found via an external tool minting a subscription
// token independently and getting a signature mismatch, then confirmed by
// direct instrumentation): this used to return []byte(existing.SecretKey)/
// []byte(created.SecretKey), i.e. the hex STRING's raw ASCII bytes (64 of
// them) rather than the 32 bytes hex.EncodeToString below actually encoded.
// Harmless in practice up to now - every process derives the same wrong
// value from the same DB row deterministically, so any two processes still
// agree with each other - but it meant the effective key was never the
// documented 32 bytes, and nothing outside this process could ever
// correctly reconstruct a valid signature from the stored value.
func ensureJWTSecret(ctx context.Context, q *generated.Queries) ([]byte, error) {
	existing, err := q.GetJWTSecret(ctx)
	if err == nil {
		return hex.DecodeString(existing.SecretKey)
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		return nil, err
	}

	raw := make([]byte, 32)
	if _, err := rand.Read(raw); err != nil {
		return nil, err
	}
	secretHex := hex.EncodeToString(raw)
	if _, err := q.CreateJWTSecret(ctx, secretHex); err != nil {
		return nil, err
	}
	return raw, nil
}

// ensureTLS returns the singleton tls row, generating the Trust-branded
// self-signed CA/panel identity on first boot if none exists yet.
func ensureTLS(ctx context.Context, q *generated.Queries, logger *slog.Logger) error {
	_, err := q.GetTLS(ctx)
	if err == nil {
		return nil
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		return err
	}

	pair, _, err := certs.GenerateCA()
	if err != nil {
		return err
	}
	if _, err := q.CreateTLS(ctx, generated.CreateTLSParams{Key: pair.KeyPEM, Certificate: pair.CertPEM}); err != nil {
		return err
	}
	logger.Info("generated Trust CA/panel certificate", "cn", certs.CommonName)
	return nil
}
