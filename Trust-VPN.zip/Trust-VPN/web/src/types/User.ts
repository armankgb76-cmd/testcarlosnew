// Mirrors internal/httpapi/user.go's userResponseDTO/userWriteRequest -
// the Go backend's actual field set, not the old Python-targeting frontend's.
// Notably absent from the old type and present here: `online_at` (added to
// the Go DTO this same phase) and `excluded_inbounds`. Deliberately omits
// `links` even though the backend's single-user GET now returns it (added
// for external panel-management bot compatibility, e.g. external
// tools reading a user's share links directly - see internal/httpapi/
// system.go's compatAPIVersion and user.go's handleGetUser) - the
// dashboard itself never reads it, it always uses `subscription_url`, and
// node connection states ("error"/"connecting"/"connected") were never real
// user statuses to begin with, just leftover node-status values on the same
// old union. `admin` is a nested object (not a flat `admin_username` string)
// and `sub_updated_at`/`sub_last_user_agent`/`emergency_used_at` were added
// specifically to match the standard panel-API wire shape an external bot
// expects - the dashboard doesn't read any of these four fields today.
export type Status = "active" | "disabled" | "limited" | "expired" | "on_hold";

export type ProtocolType = "vmess" | "vless" | "trojan" | "shadowsocks" | "hysteria2" | "tuic" | "snell" | "anytls" | "hysteria" | "naive" | "shadowtls";

// The Go backend accepts/returns each protocol's settings as an opaque JSON
// object (proxysettings.Settings, marshaled through json.RawMessage) - the
// frontend never needs to know the shape of any one protocol's settings, only
// which protocols are present, so this stays a loose record rather than a
// per-protocol union.
export type ProxySettingsMap = Record<string, Record<string, unknown>>;

// The write-side shape additionally allows an explicit `null` per protocol -
// PUT /api/user/:username treats that as "remove this one", vs. a protocol
// key missing entirely ("leave it exactly as it is"). See UserWritePayload's
// own doc comment.
export type ProxySettingsWriteMap = Record<string, Record<string, unknown> | null>;

export type DataLimitResetStrategy =
  | "no_reset"
  | "day"
  | "week"
  | "month"
  | "year";

// map[string][]string on the Go side: protocol -> inbound tags.
export type UserInbounds = Record<string, string[]>;

export type NextPlan = {
  data_limit: number;
  expire: number;
  add_remaining_traffic: boolean;
  fire_on_either: boolean;
};

// Mirrors internal/httpapi/admin.go's adminDTO - defined locally rather than
// imported from Admin.ts, matching this file's existing NextPlan precedent
// of keeping each response type self-contained.
export type UserAdmin = {
  id: number;
  username: string;
  is_sudo: boolean;
  telegram_id: number | null;
  discord_webhook: string | null;
  users_usage: number | null;
};

export type User = {
  id: number;
  username: string;
  status: Status;
  used_traffic: number;
  lifetime_used_traffic: number;
  data_limit: number | null;
  data_limit_reset_strategy: DataLimitResetStrategy;
  expire: number | null;
  note: string | null;
  created_at: string;
  on_hold_expire_duration: number | null;
  on_hold_timeout: string | null;
  auto_delete_in_days: number | null;
  sub_updated_at: string | null;
  sub_last_user_agent: string | null;
  emergency_used_at: string | null;
  admin: UserAdmin | null;
  // Non-null only for a Gateway replica (see internal/httpapi/gateway_sync.go) -
  // a real local user always has this null. The panel that pushed this user
  // out to us is the only one allowed to change it - see UsersAdmin.tsx's own
  // read-only treatment, matching the backend's own rejection of a direct edit.
  synced_from_panel_name: string | null;
  proxies: ProxySettingsMap;
  inbounds: UserInbounds;
  excluded_inbounds: UserInbounds;
  next_plan: NextPlan | null;
  subscription_url: string;
  /** Every address the subscription answers on, the one to show first first. */
  subscription_urls?: string[];
  /** Last traffic seen. With live presence it is the later of that and the last
   * time the user had an open connection. */
  online_at: string | null;
  /** Connected right now, from live connection counts (an open connection on a
   * node within the last 15 s). Absent on a backend that predates it - then the
   * old rule applies: traffic within 180 s of `online_at` (see utils/presence.ts). */
  online?: boolean;
};

export type UsersListResponse = {
  users: User[];
  total: number;
};

// The subset userWriteRequest actually accepts, shared by create (which also
// requires `username`) and edit (which allows every field to be omitted -
// PUT /api/user/:username is a partial update, not a full replace, `proxies`
// included: a protocol key missing entirely is left untouched, only an
// explicit `null` removes it - see ProxySettingsWriteMap's own doc comment).
export type UserWritePayload = {
  status?: Status;
  proxies?: ProxySettingsWriteMap;
  inbounds?: UserInbounds;
  expire?: number | null;
  data_limit?: number | null;
  data_limit_reset_strategy?: DataLimitResetStrategy;
  note?: string | null;
  on_hold_expire_duration?: number | null;
  on_hold_timeout?: string | null;
  auto_delete_in_days?: number | null;
  next_plan?: NextPlan | null;
};

export type UserCreatePayload = UserWritePayload & { username: string };
