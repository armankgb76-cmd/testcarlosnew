import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { GatewayAdmin } from "trust-ui/GatewayAdmin";

export const GatewayPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="gateway">
      <div className="p-6">
        <h1 className="mb-1 text-2xl font-bold">{t("trust.gateway.pageTitle")}</h1>
        <p className="mb-6 text-sm text-trust-muted">{t("trust.gateway.pageDesc")}</p>
        <GatewayAdmin />
      </div>
    </TrustShell>
  );
};

export default GatewayPage;
