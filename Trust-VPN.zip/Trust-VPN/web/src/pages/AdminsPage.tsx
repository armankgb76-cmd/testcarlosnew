import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { AdminsAdmin } from "trust-ui/AdminsAdmin";
import { InactiveAdmins } from "trust-ui/InactiveAdmins";

export const AdminsPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="admins">
      <div className="flex flex-col gap-6 p-6">
        <div>
          <h1 className="mb-1 text-2xl font-bold">{t("trust.admins.title")}</h1>
          <p className="text-sm text-trust-muted">{t("trust.admins.subtitle")}</p>
        </div>
        <AdminsAdmin />
        <InactiveAdmins />
      </div>
    </TrustShell>
  );
};

export default AdminsPage;
