import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { TunnelsAdmin } from "trust-ui/TunnelsAdmin";

export const TunnelsPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="tunnels">
      <div className="p-6">
        <h1 className="mb-1 text-2xl font-bold">{t("trust.tunnels.title")}</h1>
        <p className="mb-6 text-sm text-trust-muted">{t("trust.tunnels.subtitle")}</p>
        <TunnelsAdmin />
      </div>
    </TrustShell>
  );
};

export default TunnelsPage;
