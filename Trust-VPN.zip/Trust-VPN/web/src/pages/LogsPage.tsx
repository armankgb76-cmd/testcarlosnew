import { FC } from "react";
import { TrustShell } from "trust-ui/Shell";
import { Logs } from "trust-ui/Logs";

export const LogsPage: FC = () => (
  <TrustShell active="logs">
    <div className="p-6">
      <Logs />
    </div>
  </TrustShell>
);

export default LogsPage;
