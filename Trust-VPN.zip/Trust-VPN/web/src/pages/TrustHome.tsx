import { FC } from "react";
import { TrustShell } from "trust-ui/Shell";
import { OverviewNew } from "./OverviewNew";

export const TrustHome: FC = () => (
  <TrustShell active="overview">
    <OverviewNew />
  </TrustShell>
);

export default TrustHome;
