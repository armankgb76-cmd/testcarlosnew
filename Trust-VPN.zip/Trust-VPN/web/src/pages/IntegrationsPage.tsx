import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { IntegrationsForm } from "trust-ui/IntegrationsForm";

export const IntegrationsPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="integrations">
      <div className="p-6">
        <h1 className="mb-1 text-2xl font-bold">{t("trust.integrations.title")}</h1>
        <p className="mb-6 text-sm text-trust-muted">{t("trust.integrations.subtitle")}</p>
        <IntegrationsForm />
      </div>
    </TrustShell>
  );
};

export default IntegrationsPage;
