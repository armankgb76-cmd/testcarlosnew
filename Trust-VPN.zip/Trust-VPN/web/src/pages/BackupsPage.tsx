import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { BackupsAdmin } from "trust-ui/BackupsAdmin";

export const BackupsPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="backups">
      <div className="p-6">
        <h1 className="mb-1 text-2xl font-bold">{t("trust.backups.pageTitle")}</h1>
        <p className="mb-6 text-sm text-trust-muted">{t("trust.backups.pageDesc")}</p>
        <BackupsAdmin />
      </div>
    </TrustShell>
  );
};

export default BackupsPage;
