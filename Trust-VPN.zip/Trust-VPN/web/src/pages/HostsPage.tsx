import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { HostsAdmin } from "trust-ui/HostsAdmin";

export const HostsPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="hosts">
      <div className="p-6">
        <h1 className="mb-1 text-2xl font-bold">{t("trust.hosts.title")}</h1>
        <p className="mb-6 text-sm text-trust-muted">{t("trust.hosts.subtitle")}</p>
        <HostsAdmin />
      </div>
    </TrustShell>
  );
};

export default HostsPage;
