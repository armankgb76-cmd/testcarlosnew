import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { TicketsAdmin } from "trust-ui/TicketsAdmin";

export const TicketsPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="tickets">
      <div className="flex flex-col gap-6 p-6">
        <div>
          <h1 className="mb-1 text-2xl font-bold">{t("trust.tickets.title")}</h1>
          <p className="text-sm text-trust-muted">{t("trust.tickets.subtitle")}</p>
        </div>
        <TicketsAdmin />
      </div>
    </TrustShell>
  );
};

export default TicketsPage;
