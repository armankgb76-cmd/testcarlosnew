import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { UsersTable } from "trust-ui/UsersTable";
import { UserFormModal } from "trust-ui/UserFormModal";
import { UserActionModals } from "trust-ui/UserActionModals";

export const UsersPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="users">
      <div className="p-4 sm:p-6">
        <h1 className="mb-6 text-2xl font-bold">{t("users")}</h1>
        <UsersTable />
      </div>
      <UserFormModal />
      <UserActionModals />
    </TrustShell>
  );
};

export default UsersPage;
