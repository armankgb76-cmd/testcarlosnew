import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { UserTemplatesAdmin } from "trust-ui/UserTemplatesAdmin";

export const UserTemplatesPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="templates">
      <div className="p-6">
        <h1 className="mb-1 text-2xl font-bold">{t("trust.templates.title")}</h1>
        <p className="mb-6 text-sm text-trust-muted">{t("trust.templates.subtitle")}</p>
        <UserTemplatesAdmin />
      </div>
    </TrustShell>
  );
};

export default UserTemplatesPage;
