import { FC } from "react";
import { useTranslation } from "react-i18next";
import { TrustShell } from "trust-ui/Shell";
import { NodesAdmin } from "trust-ui/NodesAdmin";

export const NodesPage: FC = () => {
  const { t } = useTranslation();

  return (
    <TrustShell active="nodes">
      <div className="p-6">
        <h1 className="mb-1 text-2xl font-bold">{t("trust.nodes.title")}</h1>
        <p className="mb-6 text-sm text-trust-muted">{t("nodes.title")}</p>
        <NodesAdmin />
      </div>
    </TrustShell>
  );
};

export default NodesPage;
