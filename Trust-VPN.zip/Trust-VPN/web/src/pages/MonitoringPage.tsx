import { FC } from "react";
import { TrustShell } from "trust-ui/Shell";
import { Monitoring } from "trust-ui/Monitoring";

export const MonitoringPage: FC = () => (
  <TrustShell active="monitoring">
    <div className="p-6">
      <Monitoring />
    </div>
  </TrustShell>
);

export default MonitoringPage;
