import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { fetch } from "service/http";
import { CreateInboundPayload, Inbound, InboundListEntry, InboundsByProtocol } from "types/Inbound";
import { XrayImportRequest, XrayImportResult } from "types/XrayImport";
import { portsByTag } from "utils/inboundPorts";
import { queryKeys } from "utils/queryClient";

// GET /api/inbounds - protocol -> tag list (see types/Inbound.ts on why this
// is simpler than the old dashboard's per-inbound-metadata shape). Shared by
// the Users and User Templates forms via trust-ui/InboundsPicker.tsx, and
// by trust-ui/HostsAdmin.tsx's own "which tag to add a host under" picker.
// Inbound management itself (create/edit/delete) now lives entirely in the
// merged Core Config page (trust-ui/XrayConfigAdmin.tsx, hooks/
// useXrayConfigQuery.ts) - this hook is read-only from here on.
// The API itself returns one object per inbound ({tag, protocol, network,
// tls, port}), matching the panel API shape that every third-party
// client is written against. Nothing in this dashboard needs more than the
// tag, so the objects are flattened to tags here, in one place, instead of
// reshaping every consumer.
type RawInbounds = Record<string, Array<Partial<InboundListEntry> & { tag: string } | string>>;

const fetchInbounds = () => fetch<RawInbounds>("/inbounds");

const toTagsByProtocol = (raw: RawInbounds): InboundsByProtocol => {
  const byProtocol: InboundsByProtocol = {};
  for (const [protocol, entries] of Object.entries(raw ?? {})) {
    byProtocol[protocol] = (entries ?? []).map((entry) => (typeof entry === "string" ? entry : entry.tag));
  }
  return byProtocol;
};

export const useInboundsQuery = () =>
  useQuery({ queryKey: queryKeys.inbounds, queryFn: fetchInbounds, select: toTagsByProtocol });

// Same query key and fetch as useInboundsQuery (one request, one cache
// entry), just a different view of the response - the Core Config page shows
// every port an inbound listens on.
export const useInboundPortsQuery = () =>
  useQuery({ queryKey: queryKeys.inbounds, queryFn: fetchInbounds, select: portsByTag });

// POST /api/inbounds/import-xray - called twice per real import: once
// with confirm:false (a pure preview - parses and reports counts/warnings,
// writes nothing) and, only if the admin reviews that and proceeds, again
// with confirm:true (actually writes). Both calls use this same mutation;
// the caller decides the body's `confirm` value. A confirmed import
// touches inbounds, hosts, and core-config, so all of their caches (plus
// the merged xrayConfig query that reads two of them at once) are
// invalidated on success - but only when something was actually written (a
// preview response comes back with the exact same shape, so gate the
// invalidation on `applied` rather than skip it for preview calls via a
// separate code path).
// POST /api/inbounds - a direct, one-shot "add this protocol on this port"
// create for the dashboard's own "+ Add inbound" / "+ Add all protocols"
// actions (see internal/httpapi/inbounds.go's handleCreateInbound), as
// opposed to useImportXrayConfigMutation's bulk/upsert-by-tag shape. Touches
// inbounds, hosts, and core-config the same way an import does, so the same
// three caches are invalidated on every successful create.
export const useCreateInboundMutation = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: CreateInboundPayload) => fetch<Inbound>("/inbounds", { method: "POST", body }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.inbounds });
      queryClient.invalidateQueries({ queryKey: queryKeys.hosts });
      queryClient.invalidateQueries({ queryKey: queryKeys.xrayConfig });
    },
  });
};

export const useImportXrayConfigMutation = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: XrayImportRequest) =>
      fetch<XrayImportResult>("/inbounds/import-xray", { method: "POST", body }),
    onSuccess: (result) => {
      if (!result.applied) return;
      queryClient.invalidateQueries({ queryKey: queryKeys.inbounds });
      queryClient.invalidateQueries({ queryKey: queryKeys.hosts });
      queryClient.invalidateQueries({ queryKey: queryKeys.xrayConfig });
    },
  });
};
