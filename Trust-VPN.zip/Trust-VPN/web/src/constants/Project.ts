export const REPO_URL = "https://github.com/your-org/trust";
export const ORGANIZATION_URL = "https://github.com/your-org";
