import { FC, useState } from "react";
import { useTranslation } from "react-i18next";
import classNames from "classnames";
import {
  useActivateAdminUsersMutation,
  useAdminsQuery,
  useCreateAdminMutation,
  useDeleteAdminMutation,
  useDisableAdminUsersMutation,
  useResetAdminUsageMutation,
  useUpdateAdminMutation,
} from "hooks/useAdminsQuery";
import { useCurrentAdminQuery } from "hooks/useCurrentAdminQuery";
import { Admin } from "types/Admin";
import { errorText } from "service/errors";
import { Card } from "trust-ui/Card";
import { Badge } from "trust-ui/Badge";
import { Button } from "trust-ui/Button";
import { Input } from "trust-ui/Input";
import { Checkbox } from "trust-ui/Checkbox";
import { Modal } from "trust-ui/Modal";
import { formatBytes } from "utils/formatByte";

// ---------------------------------------------------------------------------

const AdminForm: FC<{
  initial: Admin | null;
  /** Whether the logged-in admin viewing this form is themselves an owner -
   * only an owner can grant/revoke owner access, or revoke (not grant)
   * sudo access, so the Owner checkbox only renders for one, and is_owner
   * is only ever sent by one (see handleUpdateAdmin's own permission
   * checks - this is a UI convenience, not the real enforcement). */
  viewerIsOwner: boolean;
  viewerUsername: string | undefined;
  onClose: () => void;
}> = ({ initial, viewerIsOwner, viewerUsername, onClose }) => {
  const { t } = useTranslation();
  const isEdit = !!initial;
  const [username, setUsername] = useState(initial?.username ?? "");
  const [password, setPassword] = useState("");
  const [isSudo, setIsSudo] = useState(initial?.is_sudo ?? false);
  const [isOwner, setIsOwner] = useState(initial?.is_owner ?? false);
  const [telegramId, setTelegramId] = useState(
    initial?.telegram_id != null ? String(initial.telegram_id) : ""
  );
  const [discord, setDiscord] = useState(initial?.discord_webhook ?? "");
  const [error, setError] = useState("");

  const createAdmin = useCreateAdminMutation();
  const updateAdmin = useUpdateAdminMutation();
  const saving = createAdmin.isPending || updateAdmin.isPending;

  const submit = () => {
    setError("");
    const request = isEdit
      ? updateAdmin.mutateAsync({
          username: initial!.username,
          body: {
            is_sudo: isSudo,
            // Omitted entirely for a non-owner viewer, not just left at its
            // starting value - the backend treats "field present" as "I
            // intend to touch this" for is_owner specifically (see its own
            // comment), so a non-owner must never send it at all.
            is_owner: viewerIsOwner ? isOwner : undefined,
            telegram_id: telegramId ? Number(telegramId) : null,
            // Left blank on edit means "keep the current password" - sending
            // an empty string would hash it and lock the admin out.
            password: password || undefined,
            discord_webhook: discord || null,
          },
        })
      : createAdmin.mutateAsync({
          username,
          password,
          is_sudo: isSudo,
          telegram_id: telegramId ? Number(telegramId) : null,
          discord_webhook: discord || null,
        });

    request.then(onClose).catch((e) => setError(errorText(e, t("trust.admins.saveFailed"))));
  };

  const canSubmit = isEdit ? true : !!username && !!password;

  return (
    <Modal onClose={onClose} className="max-w-md">
      <h2 className="mb-4 text-lg font-semibold">
        {isEdit ? t("trust.admins.editTitle") : t("trust.admins.addTitle")}
      </h2>
      <div className="flex flex-col gap-3">
        <label className="flex flex-col gap-1">
          <span className="text-xs text-trust-muted">{t("username")}</span>
          <Input
            dir="ltr"
            value={username}
            disabled={isEdit}
            onChange={(e) => setUsername(e.target.value)}
          />
        </label>

        <label className="flex flex-col gap-1">
          <span className="text-xs text-trust-muted">
            {t("password")}
            {isEdit ? ` — ${t("trust.admins.passwordKeepHint")}` : ""}
          </span>
          <Input
            dir="ltr"
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>

        <Checkbox
          checked={isSudo}
          disabled={isEdit && !!initial?.is_sudo && !viewerIsOwner}
          onChange={(e) => setIsSudo(e.target.checked)}
          label={t("trust.admins.isSudo")}
        />
        {isSudo && (
          <p className="-mt-1 text-xs text-amber-400">{t("trust.admins.sudoWarning")}</p>
        )}
        {isEdit && initial?.is_sudo && !viewerIsOwner && (
          <p className="-mt-1 text-xs text-trust-muted">{t("trust.admins.onlyOwnerRevokesSudo")}</p>
        )}

        {viewerIsOwner && (
          <>
            {(() => {
              const editingSelf = isEdit && initial?.username === viewerUsername;
              const lockedOwner = !!initial?.is_owner && editingSelf;
              return (
                <>
                  <Checkbox
                    checked={isOwner}
                    disabled={lockedOwner}
                    onChange={(e) => setIsOwner(e.target.checked)}
                    label={t("trust.admins.isOwner")}
                  />
                  {isOwner && (
                    <p className="-mt-1 text-xs text-amber-400">{t("trust.admins.ownerWarning")}</p>
                  )}
                  {lockedOwner && (
                    <p className="-mt-1 text-xs text-trust-muted">{t("trust.admins.cannotSelfRemoveOwner")}</p>
                  )}
                </>
              );
            })()}
          </>
        )}

        <label className="flex flex-col gap-1">
          <span className="text-xs text-trust-muted">{t("trust.admins.telegramId")}</span>
          <Input
            dir="ltr"
            inputMode="numeric"
            value={telegramId}
            onChange={(e) => setTelegramId(e.target.value.replace(/[^0-9-]/g, ""))}
          />
        </label>

        <label className="flex flex-col gap-1">
          <span className="text-xs text-trust-muted">{t("trust.admins.discordWebhook")}</span>
          <Input
            dir="ltr"
            value={discord}
            onChange={(e) => setDiscord(e.target.value)}
            placeholder="https://discord.com/..."
          />
        </label>

        {error && (
          <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-400">
            {error}
          </div>
        )}

        <div className="mt-2 flex justify-end gap-2">
          <Button variant="chip" onClick={onClose}>
            {t("cancel")}
          </Button>
          <Button variant="chip" tone="accent" disabled={saving || !canSubmit} onClick={submit}>
            {saving ? t("trust.pleaseWait") : t("trust.admins.save")}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

// ---------------------------------------------------------------------------

const AdminCard: FC<{
  row: Admin;
  isSelf: boolean;
  onEdit: () => void;
}> = ({ row, isSelf, onEdit }) => {
  const { t } = useTranslation();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmDisable, setConfirmDisable] = useState(false);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const deleteAdmin = useDeleteAdminMutation();
  const disableUsers = useDisableAdminUsersMutation();
  const activateUsers = useActivateAdminUsersMutation();
  const resetUsage = useResetAdminUsageMutation();

  const remove = () => {
    setMsg(null);
    deleteAdmin.mutate(row.username, {
      onSuccess: () => setMsg({ tone: "ok", text: t("trust.admins.deleted") }),
      onError: (e) => {
        setMsg({ tone: "err", text: errorText(e, t("trust.admins.actionFailed")) });
        setConfirmDelete(false);
      },
    });
  };

  const disable = () => {
    setMsg(null);
    setConfirmDisable(false);
    disableUsers.mutate(row.username, {
      onSuccess: () => setMsg({ tone: "ok", text: t("trust.admins.usersDisabled") }),
      onError: (e) => setMsg({ tone: "err", text: errorText(e, t("trust.admins.actionFailed")) }),
    });
  };

  const activate = () => {
    setMsg(null);
    activateUsers.mutate(row.username, {
      onSuccess: () => setMsg({ tone: "ok", text: t("trust.admins.usersActivated") }),
      onError: (e) => setMsg({ tone: "err", text: errorText(e, t("trust.admins.actionFailed")) }),
    });
  };

  const doResetUsage = () => {
    setMsg(null);
    resetUsage.mutate(row.username, {
      onSuccess: () => setMsg({ tone: "ok", text: t("trust.admins.usageReset") }),
      onError: (e) => setMsg({ tone: "err", text: errorText(e, t("trust.admins.actionFailed")) }),
    });
  };

  return (
    <Card
      className={classNames(
        "p-4",
        row.is_owner
          ? "!border-orange-500/60 bg-orange-500/[0.04]"
          : row.is_sudo
            ? "!border-trust-accent/60 bg-trust-accent/[0.04]"
            : "!border-sky-500/60 bg-sky-500/[0.04]"
      )}
    >
      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <span className="truncate text-sm font-semibold" dir="ltr">
              {row.username}
            </span>
            <Badge tone={row.is_sudo ? "brand" : "sky"}>
              {row.is_sudo ? t("trust.admins.sudo") : t("trust.admins.reseller")}
            </Badge>
            {row.is_owner && <Badge tone="orange">{t("trust.admins.owner")}</Badge>}
            {isSelf && <Badge tone="gray">{t("trust.admins.you")}</Badge>}
          </div>
          <span className="text-xs text-trust-muted">
            {t("trust.admins.usage")}{" "}
            <span className="tabular-nums text-trust-text" dir="ltr">
              {formatBytes(row.users_usage || 0)}
            </span>
          </span>
        </div>

        {(row.telegram_id || row.discord_webhook) && (
          <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-trust-muted">
            {row.telegram_id ? (
              <span>
                Telegram: <span className="text-trust-text" dir="ltr">{row.telegram_id}</span>
              </span>
            ) : null}
            {row.discord_webhook ? <span>Discord ✓</span> : null}
          </div>
        )}

        {msg && (
          <div
            className={classNames(
              "rounded-lg border px-3 py-2 text-xs",
              msg.tone === "ok"
                ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400"
                : "border-red-500/30 bg-red-500/10 text-red-400"
            )}
          >
            {msg.text}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-1.5">
          <Button variant="chip" tone="accent" onClick={onEdit}>
            {t("trust.edit")}
          </Button>

          {confirmDisable ? (
            <>
              <span className="text-xs text-amber-400">{t("trust.admins.disableWarning")}</span>
              <Button variant="chip" tone="red" disabled={disableUsers.isPending} onClick={disable}>
                {t("trust.admins.disableUsers")}
              </Button>
              <Button variant="chip" onClick={() => setConfirmDisable(false)}>
                {t("cancel")}
              </Button>
            </>
          ) : (
            <Button variant="chip" tone="red" onClick={() => setConfirmDisable(true)}>
              {t("trust.admins.disableUsers")}
            </Button>
          )}

          <Button variant="chip" tone="sky" disabled={activateUsers.isPending} onClick={activate}>
            {t("trust.admins.activateUsers")}
          </Button>

          <Button variant="chip" tone="amber" disabled={resetUsage.isPending} onClick={doResetUsage}>
            {t("trust.admins.resetUsage")}
          </Button>

          {/* Deleting yourself would end the session you are working in, and
              deleting an admin orphans their customers - both get a guard. */}
          {!isSelf &&
            (confirmDelete ? (
              <>
                <span className="text-xs text-red-400">{t("trust.admins.deleteWarning")}</span>
                <Button variant="chip" tone="red" disabled={deleteAdmin.isPending} onClick={remove}>
                  {t("delete")}
                </Button>
                <Button variant="chip" onClick={() => setConfirmDelete(false)}>
                  {t("cancel")}
                </Button>
              </>
            ) : (
              <Button variant="chip" tone="red" onClick={() => setConfirmDelete(true)}>
                {t("delete")}
              </Button>
            ))}
        </div>
      </div>
    </Card>
  );
};

// ---------------------------------------------------------------------------

export const AdminsAdmin: FC = () => {
  const { t } = useTranslation();
  const { data: currentAdmin } = useCurrentAdminQuery();
  const { data: rows, isLoading, isError } = useAdminsQuery();
  const [editing, setEditing] = useState<Admin | null | undefined>(undefined);

  const sudoCount = (rows ?? []).filter((r) => r.is_sudo).length;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-sm text-trust-muted">
          {t("trust.admins.summary", { total: rows?.length ?? 0, sudo: sudoCount })}
        </div>
        <Button variant="chip" tone="accent" onClick={() => setEditing(null)}>
          + {t("trust.admins.addTitle")}
        </Button>
      </div>

      {isError && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-400">
          {t("trust.admins.loadFailed")}
        </div>
      )}

      {isLoading ? (
        <p className="text-sm text-trust-muted">{t("trust.tickets.loading")}</p>
      ) : (rows ?? []).length === 0 ? (
        <Card className="p-6 text-center text-sm text-trust-muted">
          {t("trust.admins.empty")}
        </Card>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {(rows ?? []).map((row) => (
            <AdminCard
              key={row.username}
              row={row}
              isSelf={row.username === currentAdmin?.username}
              onEdit={() => setEditing(row)}
            />
          ))}
        </div>
      )}

      {editing !== undefined && (
        <AdminForm
          initial={editing}
          viewerIsOwner={!!currentAdmin?.is_owner}
          viewerUsername={currentAdmin?.username}
          onClose={() => setEditing(undefined)}
        />
      )}
    </div>
  );
};

export default AdminsAdmin;
