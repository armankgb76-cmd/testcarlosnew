import { FC } from "react";
import { ORGANIZATION_URL, REPO_URL } from "constants/Project";

export const TrustFooter: FC = () => (
  // Entirely Latin and punctuation-heavy; left in the surrounding RTL run the
  // bidi algorithm moves the comma to the wrong side of "Trust".
  <div dir="ltr" className="w-full py-2 text-center text-xs text-trust-muted">
    <a href={REPO_URL} className="text-trust-accent hover:underline">
      Trust VPN
    </a>
    {", "}Made with ❤️ by{" "}
    <a href={ORGANIZATION_URL} className="text-trust-accent hover:underline">
      your-org
    </a>
  </div>
);
