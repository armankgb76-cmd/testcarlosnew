/** @type {import('tailwindcss').Config} */
module.exports = {
  // The whole dashboard is this UI - every page that can render a Tailwind
  // class needs to be listed here or its classes get purged from the build.
  content: [
    "./src/trust-ui/**/*.{ts,tsx}",
    "./src/pages/TrustHome.tsx",
    "./src/pages/OverviewNew.tsx",
    "./src/pages/UsersPage.tsx",
    "./src/pages/HostsPage.tsx",
    "./src/pages/AdminsPage.tsx",
    "./src/pages/IntegrationsPage.tsx",
    "./src/pages/UserTemplatesPage.tsx",
    "./src/pages/Login.tsx",
  ],
  theme: {
    extend: {
      // Same list as --trust-font-sans (src/index.scss). This exists so
      // `font-sans` means the right thing wherever it is used, rather than
      // leaving it to whatever the browser's default sans-serif is.
      fontFamily: {
        sans: [
          "Inter",
          "Vazirmatn",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "Oxygen",
          "Ubuntu",
          "Cantarell",
          "Fira Sans",
          "Droid Sans",
          "Helvetica Neue",
          "Tahoma",
          "sans-serif",
        ],
      },
      colors: {
        // Trust palette: a deep green ground (not neutral black - it keeps
        // a faint green cast, like light through dark glass) with purple as
        // the one accent doing exactly one job - brand and interactivity.
        // Health/status is never conveyed by this color; that's Tailwind's
        // own emerald/amber/rose, kept deliberately separate so "this is
        // clickable" and "this is healthy" never collide into one meaning.
        trust: {
          bg: "#07120e",
          surface: "#0c1a14",
          // A third surface tier the old two-tone system didn't have -
          // modals, hovers, and anything that should read as "lifted" above
          // a card without resorting to a shadow (a console's screens don't
          // cast them).
          raised: "#12261c",
          border: "#1a3a2a",
          accent: "#a855f7",
          text: "#e8f5ef",
          muted: "#7a9e8c",
        },
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};
